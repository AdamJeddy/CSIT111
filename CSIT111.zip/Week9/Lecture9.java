package Week9;

import java.io.File;
import java.util.Scanner;
/*	Name followed by ID's
 * 	Yousef	123456
 * 	Saad	213452
 * 	Adnan	887766
 * 	Adam	672349
 * 	
 * 	Class Diagram
 * 	_____________________
 * |      Students     	 |
 * |_____________________|
 * |String name			 | |--- Atributes, Data members
 * |Int ID				 | |
 * |_____________________|
 * |Construsctors		 |
 * |_____________________|
 * |String toString		 |	|
 * |String getName		 |	|--- Methods is a function belongs to the class
 * |int getID			 |	|
 * |_____________________|
 * 
 * Object Orientation is :
 * 		Abstruction
 * 		Encapsulation
 * 		Modularity
 * 		Software reuse
 * 
 * 1. Read the file into an arrys of students
 * 2. List it back to the screen 
 * 3. Write a function
 * 4. Rewrite back to another file with only the names
 * 5. Rewrite the student list with their 
 * 
 * Private data cant be accessed from the outside 
 * 		Q. how do you access it?
 * 		A. With getters
 */

public class Lecture9 {
	public static Student search_student_by_name(Student [] list_s, String name) {
		for (int k = 0; k < list_s.length; k++) 
			if (list_s[k].get_name().equals(name)) {
				//Note when comparing Strings use .equals()
				return list_s[k];
			}
			
			Student temp = new Student("-----",-1);
			return temp;
		
	}

	public static void main(String[] args) throws Exception{
		
		Scanner in = new Scanner(System.in);//Open a communication channel
		
		System.out.println("Supper");
		
		File myfile = new File("stud.txt");
		Scanner inFile = new Scanner(myfile);
				
		Student [] list_stud = new Student [40];
		
		int n_stud = 0;//incrementer
		while (inFile.hasNext()) {
			String namee = inFile.next();
			int idd = inFile.nextInt();
			Student s = new Student(namee, idd);
			list_stud[n_stud] = s;
			n_stud++;
		}//While End
		
		for (int k = 0; k < n_stud; k++) {
			System.out.println(list_stud[k].toString());
		}//For End
		
		System.out.println("BYE BYE");
		
		while (true) {
			System.out.println("enter name");
			String name = in.next();
			Student st = search_student_by_name(list_stud, name);
			System.out.println(st.toString());
		}
	}

}
