package Week9;

public class Subject {
	private String name;
	private String id;
	private Grade Grade;
	
	//Defult const
	Subject(){
		this.name = "";
		this.id = "";
		this.Grade = new Grade();
	}
	
	//Custom const
	Subject(String name,String id){
		this.name = name;
		this.id = id;
		this.Grade = new Grade();
	}
	
	//Setters
	public void set_name(String name) {
		this.name = name;
	}
	public void set_id(String id) {
		this.id = id;
	}
	public void set_subjectGrade(String grade) {
		Grade.set_grade(grade);
	}
	public void assignGrade(double Mark) {
		set_subjectGrade(Grade.calculate_Grade(Mark));
	}
	
	//Getters
	public String get_name() {
		return name;
	}
	public String get_id() {
		return id;
	}
	public String get_grade() {
		return Grade.get_grade();
	}
	
	
}
