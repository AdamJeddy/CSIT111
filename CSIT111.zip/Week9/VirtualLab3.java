package Week9;

public class VirtualLab3 {

	public static void main(String[] args) {
	//Testing Grade Class
		System.out.println("Grade 1");
		//Grade with marks as input
		Grade grade1 = new Grade(65.0);
		grade1.set_grade("D");//put a wrong Grade
		grade1.calculate_Grade();//Calculate the marks
		//Display the grade and marks
		System.out.println("Marks: "+grade1.get_mark());
		System.out.println("Grade: "+grade1.get_grade());
		System.out.println("Marks: "+grade1.get_mark()+" | Grade: "+grade1.get_grade());
		
		System.out.println("");
		
		//Grade with no marks as input
		System.out.println("Grade 2");
		Grade grade2 = new Grade();
		grade2.set_mark(90.0);//Give mark
		grade2.set_grade("P");//Give Grade
		System.out.println("Marks: "+grade2.get_mark()+" | Grade: "+grade2.calculate_Grade());
		//i wanna sleep 
		
		System.out.println("");
		System.out.println("");
		
		
	//Testing Subject Class
		System.out.println("Subject 1");
		//Subject with inputs
		Subject subject1 = new Subject("Problem Solving", "CSIT113");
		//Set the subject Grade
		subject1.set_subjectGrade("D");
		System.out.println("SubjectName: "+subject1.get_name()+" | SubjectID: "+subject1.get_id()+
		" | SubjectGrade: "+subject1.get_grade());
		subject1.assignGrade(40);
		System.out.println("SubjectName: "+subject1.get_name()+" | SubjectID: "+subject1.get_id()+
				" | SubjectGrade: "+subject1.get_grade());
		
		System.out.println("");
		
		//Subject without inputs
		System.out.println("Subject 2");
		Subject subject2 = new Subject();
		subject2.set_name("Networking");
		subject2.set_id("CSIT127");
		subject2.set_subjectGrade("HD");
		System.out.println("SubjectName: "+subject2.get_name()+" | SubjectID: "+subject2.get_id()+
				" | SubjectGrade: "+subject2.get_grade());
		
		

		
	}

}

