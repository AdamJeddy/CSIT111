package Week9;

public class Student {
	private String name;
	private int id;
	
	public Student(String name, int id) {	
		this.name = name;	
		this.id = id;	
	}//parameter constructor
	
	
	public String toString() {
		String s = "Name: " + name + "	ID:"+id;
		return s;
	}//Display
	
	public String get_name() {
		return name;
	}
	
	public int get_id() {
		return id;
	}
	
}//Student End
