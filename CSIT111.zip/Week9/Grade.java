package Week9;

public class Grade {
	private String Grade;
	private Double mark;
	
	//Defult const
	public Grade() {
		Grade = "";
		mark = 0.0;
	}
	
	//Custom const
	public Grade(Double mark) {
		this.mark = mark;
	}
	
	//Getters
	public Double get_mark() {
		return mark;
	}
	public String get_grade() {
		return Grade;
	}
	
	//Setters
	public void set_grade(String grade) {
		this.Grade = grade;
	}
	public void set_mark(double mark) {
		this.mark = mark;
	}
	
	//calculate_Grade()
	public String calculate_Grade() {
		if (mark > 84) {
			Grade = "HD";
		}
		else if (mark > 74) {
			Grade = "D";
		}
		else if (mark > 64) {
			Grade = "C";
		}
		else if (mark > 55) {
			Grade = "P";
		}
		else {
			Grade = "F";
		}
		return Grade;
	}
	
	//calculate_Grade(Mark)
	public String calculate_Grade(double Mark) {
		if (Mark > 84) {
			Grade = "HD";
		}
		else if (mark > 74) {
			Grade = "D";
		}
		else if (mark > 64) {
			Grade = "C";
		}
		else if (mark > 55) {
			Grade = "P";
		}
		else {
			Grade = "F";
		}
		return Grade;
	}
}
