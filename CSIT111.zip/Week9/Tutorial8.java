package Week9;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Tutorial8 {
	public static boolean isEqual(int arr1[],int arr2[]) {
		if (arr1.length != arr2.length) return false;
		
		for (int i = 0; i < arr1.length; i++) {
			if (arr1[i] == arr2[i]) return false;
			
		}
		
		return true;
	}
	
	public static boolean isPrime(int n) {
		if (n <= 1) return false;
		
		for (int i = 2; i < n; i++) {
			if (n % i == 0) return false;
		}//For end
		
		//If all numbers are checked then its a prime number
		return true;
	}
	
	public static int sumPrime(int n) {
		//count of prime numbers
		int primeCounter = 1;
		int num = 1;
			
		//sum of prime numbers
		int sum = 0;
		
		while (primeCounter <= n) {
			//If numeber is prime add it
			if (isPrime(num)) {
				sum += num;
				
				//increse primeCounter
				primeCounter++;
			}//If end
			//get to next number
			num++;
		}//While End
			
		return sum;
	}
	
	public static int howManyPrime(int n) {
		//count of prime numbers
		int primeCounter = 1;
		int num = 1;
		
		while (num <= n) {
			if (isPrime(num)) {
				//increse primeCounter
				primeCounter++;
			}//If end
			//get to next number
			num++;
		}//While end
		
		return primeCounter;
	}

	public static int sumDigit() {
		Scanner in = new Scanner(System.in);
		int number, d, sum = 0;
		
		System.out.println("Enter the number");
		number = in.nextInt();
		
		while (number > 0) {
			d = number % 10;
			sum += d;
			number = number / 10;
		}//While End
		in.close();
		return sum;
	}
	
	public static int[]	readArray(String file) throws FileNotFoundException {
		//try {
			//Step 1 : Count how many lines
			//Step : Create array and copy the elements in
			int count = 0;
			Scanner in = new Scanner(new File(file));
			
			while (in.hasNext()) {
				count++;
				in.hasNextInt();
			}
			
			int a[]	= new int[count];
			
			Scanner in2 = new Scanner(new File(file));
			for (int i = 0; i < count; i++) {
				a[i] = in2.nextInt();
			}
			in.close();
			in2.close();
			return a;
	}

	public static void main(String[] args) throws FileNotFoundException{
	//Task 1 
		int arr1[] = {1,2,3,4,5};
		int arr2[] = {1,2,3,4,5};
		
		boolean resultTask1 = isEqual(arr1,arr2);
		
		if (resultTask1) 
			System.out.println("Yes, they are all equal");
		
		else 
			System.out.println("No, they are not equal");
		
	
		
	System.out.println("");
	//Task2
		int prime = 5;
		System.out.println("Test case: "+prime);
		
		if (isPrime(prime)) 
			System.out.println("Yes, its a prime");
		else
			System.out.println("Not a prime");
		
		
		
	System.out.println("");
	//Task3
		int sum = sumPrime(50);
			System.out.println("Sum of 20 prime numbers: "+sum);
			
			
			
	System.out.println("");
	//Task4
		System.out.println(sumDigit());
		
		
		
	System.out.println("");
	//Task5
		File file = new File("number.txt");
		Scanner in = new Scanner(System.in);
		
		while (in.hasNextInt()) {
			int n = in.nextInt();
			if (n % 2 == 1) {
				System.out.println(n);
			}
		}
	
		int list[];
		list = readArray("number.txt");
		
		//Display
		System.out.println("Display array");
		for (int i = 0; i < list.length; i++) {
			System.out.println(list[i]);
		}//For end
		in.close();
	}

}
