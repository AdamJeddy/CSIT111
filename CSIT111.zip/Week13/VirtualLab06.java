package Week13;

import java.io.*;
import java.util.Scanner;

import javax.xml.stream.events.Characters;

public class VirtualLab06 {

	public static void main(String[] args) throws Exception {
		/*
		 * 	� Create a program which reads values from a file, and store said values in a data structure of your choosing. 
 			� Create a class to read file contents, and separate the content based on data type(Numbers, Letters), where all Numbers are stored separately from Characters. 
 			� Write each set to a separate file and name the file according to the type. 
		 */
		
		File inFile = new File("Data2.txt");
		Scanner scan = new Scanner(inFile);
		
		
		
		String numbers = "";
		String character = "";
		String character2 = "";
		boolean isFound = false;
		
		while (scan.hasNext()) {
			
			if (scan.hasNextInt()) {
				numbers += scan.nextInt() + " ";
			}
			else if (scan.hasNextDouble()) {
				numbers += scan.nextDouble() + " ";
			}
			else {
				character += scan.next() + " ";
			}
			
		}
		
		System.out.println("Number : "+numbers);
		System.out.println("Character : "+character);
		System.out.println("");
		
		
		for (int i = 0; i < character.length(); i++) {
			for (int j = 0; j < 10; j++) {
				String temp = String.valueOf(j);
				
				if (character.charAt(i) == temp.charAt(0)) {
					numbers += temp + " ";
					isFound = true;
					//temp = "_";
					//character.replace(character.charAt(i), temp.charAt(0));
					
				}//If end
			}//For end
			if (!isFound) {
				character2 += character.charAt(i);
			}
			else {
				isFound = false;
			}
			
		}//For end
		
		System.out.println("Number2 : "+numbers);
		System.out.println("Character2 : "+character2);
		
		
	}

}
