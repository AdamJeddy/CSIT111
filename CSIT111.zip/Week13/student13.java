package Week13;

public class student13 {
	private int ID;
	private String name;	
	
	private double[] test = new double [10];
	private int number_of_test;
	
	
	public student13() {
		ID = -1;
	}
	
	
	student13(int ID, String name,double[] test, int nTest){
		this.ID = ID;
		this.name = name;
		this.test = test;
		this.number_of_test = nTest;
	}
	
	
	public int get_ID() {
		return ID;
	}
	public String get_Name() {
		return name;
	}
	
	public void addtest(double test3) {
		test[number_of_test]= test3;
		number_of_test++;
	}
	
	
	public String tostring() {
		
		String str = "ID: "+ID+" 	| Name: "+name+ " 	|";
		
		
		for (int i = 1; i < number_of_test; i++) {
			str = str + " "+test[(i-1)]+ " ";
		}
		
		return str;
		
	}


	
	
}
