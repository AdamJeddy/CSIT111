package Week13;

import java.io.*;
import java.util.*;

public class Lecture13 {
	public static int where_in_the_list_Student(student13 [] list, int N_Studnet, int ID) {
		for (int i = 0; i < N_Studnet; i++) {
			if (ID == list[i].get_ID()) {
				return i;
			}//IF end
		}//For end
		return -1;
	}

	public static void main(String[] args) throws Exception {
		
		File file = new File("student13.txt");
		Scanner inf = new Scanner(file);
		
		System.out.println("Welcome");
		int n_students = inf.nextInt();
		System.out.println("Number of students: "+n_students);
		
		student13 [] list_students = new student13[50];
		
		for (int i = 1; i <= n_students; i++) {
			int id = inf.nextInt();
			String name = inf.next();
			double test1 = inf.nextDouble();
			double test2 = inf.nextDouble();
			
			double [] tests = new double[10];
			tests[0] = test1;
			tests[1] = test2;
			
			student13 s = new student13(id, name, tests, 2);
			
			list_students[i-1] = s;
		}//For end
		
		//Print file
		for (int k = 0; k < n_students; k++) {
			System.out.println(list_students[k].tostring());
		}
		System.out.println("BYE!");System.out.println("");
		
	
		//FILE 2
		
		File file2 = new File("test3.txt");
		Scanner inf2 = new Scanner(file2);
		
		System.out.println("================");
		for (int p = 1; p <= 3; p++) {
			int id = inf2.nextInt();
			double test3 = inf2.nextDouble();
			System.out.println("ID: "+id+" | Test: "+test3);
			int kk = where_in_the_list_Student(list_students, n_students, id);
			list_students[kk].addtest(test3);
		}//For End
		
		
		FileWriter outf = new FileWriter("three_test.txt");
		
		for (int k = 0; k < n_students; k++) {
			outf.write("ID: "+list_students[k].get_ID()+" | Name: "+list_students[k].get_Name());
			outf.write("	Test"+System.lineSeparator());
			
		}
		
		inf.close();
		inf2.close();
		outf.close();
		
	}//Method end
}//Class end
