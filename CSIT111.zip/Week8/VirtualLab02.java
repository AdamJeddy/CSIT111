package Week8;
import java.io.*;
import java.util.Arrays;


public class VirtualLab02 {

	public static void main(String[] args) throws IOException{

		//Task 1:
		File InFile = new File("C:\\Users\\Adam\\Desktop\\TestFile.txt");//Declare the file
		BufferedReader reader = new BufferedReader(new FileReader(InFile));//Open buffer to Read the file

		String str;
		str = reader.readLine();//Store the first line
		System.out.println(str);//Print the first line
		
		while ((str = reader.readLine()) != null) {//While loop till the stored line is NULL
			System.out.println(str);//Print the line
		}
		reader.close();//close reader

		
		
		
		
		System.out.println("");
		//Task 2: 
		
		File outFile = new File ("C:\\Users\\Adam\\Desktop\\TestFile2.txt");//Declare the file, if not there it makes a new one
		BufferedWriter writer = new BufferedWriter(new FileWriter(outFile));//Open buffer to Write to the Declared File
		BufferedReader reader2 = new BufferedReader(new FileReader(outFile));//Open buffer to Read the file
		
		writer.write("Adam A \n6724395 \n0558035789");//Write to the file
		writer.close();//Close the writer to save
		
		String str2;
		str2 = reader2.readLine();
		
		System.out.println(str2);
		while ((str2 = reader2.readLine()) != null) {
			System.out.println(str2);
		}//While End
		writer.close();
		reader2.close();

		
		
		
		
		System.out.println("");
		//Task 3:
		/*Read the content of file created in task 2
		 * copy the content to the file included and used in task 1. 
		 * Make sure you do NOT lose the original values when writing to the file, e.g. open in append mode.
		 */
		BufferedWriter writer2 = new BufferedWriter(new FileWriter(InFile, true));//Open a append Buffer Writer for InFile
		BufferedReader reader4file1 = new BufferedReader(new FileReader(InFile));//Open a buffer reader for InFile
		BufferedReader reader4file2 = new BufferedReader(new FileReader(outFile));//Open buffer to Read the outFile
		/* Store File 2 first line
		 * instead of looping a print command you use a write one
		 * write to the File 1
		 */
		
		String str3 = reader4file2.readLine();//Declare and store line 1 of outFile
		writer2.write(str3);//Write the stored line to InFile
		while ((str3 = reader4file2.readLine()) != null) {//Loop till all the lines written
			writer2.write(str3);
		}//WhileEnd
		
		writer2.close();
		
		String str4 = reader4file1.readLine();//Declare and store line 1 of InFile
		System.out.println(str4);
		
		while ((str4 = reader4file1.readLine()) != null) {
			 System.out.println(str4);
		}//WhileEnd
		
		reader4file1.close();
		reader4file2.close();

		
		
		
		
		System.out.println("");
		//Task 4:
		/* Read the file used in Task 2 
		 * modify the values of your student ID to today�s date
		 * write all the content to a new file.  */
	
		File task3	= new File ("C:\\Users\\Adam\\Desktop\\Task3.txt");//Declare & make the Task3 file
		BufferedReader file2Reader = new BufferedReader(new FileReader(outFile));//Open buffer reader for file 2
		BufferedWriter BWfile3 = new BufferedWriter(new FileWriter(task3));//Open a buffer writer form the Task3 file
		
		String Content = "";
		String currentReadingLine = file2Reader.readLine();//Declare and store line 1 from file2
		while (currentReadingLine != null) {//Loop till the file ends
			Content = Content + currentReadingLine + System.lineSeparator();
			currentReadingLine = file2Reader.readLine();
		}
		//Replace the following in the file3
		String newContent = Content.replaceAll("6724395", "3/4/20");
		//Write the newContent to file3 and close all the buffers
		BWfile3.write(newContent);
		file2Reader.close();
		BWfile3.close();
		
		//Time to check if its right or not 
		BufferedReader BR3 = new BufferedReader(new FileReader(task3));
		
		String file3read = BR3.readLine();
		System.out.println(file3read);
		while ((file3read = BR3.readLine()) != null) {
			System.out.println(file3read);
		}
		BR3.close();
		file2Reader.close();

		
		
		
		System.out.println("");
		/*Task 5 :
		 * Read file in Task 2
		 * find student ID, sort value from min to max
		 * save it in the same file (Task 2)
		 * Do not lose the original values
		 */
		System.out.println("Task 5");
		File task2File = new File ("C:\\Users\\Adam\\Desktop\\TestFile2.txt");
		//Buffer for reading outFile (File 2)
		BufferedReader readFile2 = new BufferedReader(new FileReader(task2File));
		//Buffer for writing to outFile which is File 2
		BufferedWriter writeFile3 = new BufferedWriter(new FileWriter(task2File, true));
		
		String text = "";
		String s;
		
		s = readFile2.readLine();
		while (s != null) {
			text += s + System.lineSeparator();
			s = readFile2.readLine();
		}
		
		int[] arr = {6,7,2,4,3,9,5};
		
		arr = sortArray(arr);//Using the sorting method
		
		
		System.out.println(Arrays.toString(arr));
		
		String arrJoin = "";
		for (int i = 0; i < arr.length; i++) {
			arrJoin += String.valueOf(arr[i]) ;
		}
		writeFile3.newLine();
		writeFile3.write(arrJoin);
		
		readFile2.close();
		writeFile3.close();
		
	}
	public static int[] sortArray(int[] arr) { 
        // Finding the length of array 
        int length = arr.length; 
  
        // Sorting using a single loop 
        for (int j = 0; j < length - 1; j++) { 
  
            // Checking the condition for two numbers of the array 
            if (arr[j] > arr[j + 1]) { 
  
                // Swapping the elements if arr[j] > arr[j + 1] is true. 
                int temp = arr[j]; 
                arr[j] = arr[j + 1]; 
                arr[j + 1] = temp; 
  
                // the loop begins from the start. 
                j = -1; 
            }//If end 
        }//For end
        return arr; 
    } 

}
