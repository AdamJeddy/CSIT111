package Week8;

public class Book {
	private String title;
	private int ISBN;
	private int copies;
	private String authorName;
	private String publisherName;
	
	Book(){ //defult constructor
		title = " ";
		ISBN = 0;
		copies = 0;
		authorName = " ";
		publisherName = " ";
	}
	
	public Book (String title, int ISBN, int copies, String authorName, String publisherName) {
		this.title = title;
		this.ISBN = ISBN;
		this.copies = copies;
		this.authorName = authorName;
		this.publisherName = publisherName;
	}
	
	String tostring() {
		String toString ="Title: " + title + " | ISBN: " + ISBN + " | Copies: " + copies + " | Author Name: " + authorName + " | Publisher Name: " + publisherName;
		return toString;
	}//end toString
	
	void increment_copy() {
		copies++;
		if (copies > 10) {
			copies = 10;
		}//if end
	}//void end
	
	void decrement_copy() {
		copies--;
		if (copies < 0) {
			copies = 0;
		}//if end
	}//void end
}
