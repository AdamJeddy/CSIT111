package Week8;

public class rectangle {
	private int lenght;
	private int width;
	
	//Constructor
	rectangle(){
		
	}
	
	//Getters / Accessor
	public int getLenght() {
		
		return lenght;
	}
	
	public int getWidth() {
		
		return width;
	}
	
	
	//Setters / Mutator
	public void setLenght (int l) {
		lenght = l;
	}
	
	public void setWidth (int w) {
		width = w;
	}
	
	
	//Methods
	public double calculateArea() {
		double a = this.lenght * this.width;
		return a;
	}
	
	
	
}
