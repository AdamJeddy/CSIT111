package Week8;

public class Tutorial07_Q1 {

	public static void main(String[] args) {
		rectangle r1;
		r1 = new rectangle();
		
		r1.setLenght(10);
		r1.setWidth(5);
		
		System.out.println("Lenght is :"+ r1.getLenght());
		System.out.println("Width is :"+ r1.getWidth());
		
		double result = r1.calculateArea();
		System.out.println("r1 area is " + result);
		System.out.println("r1 area is " + r1.calculateArea());
		
		System.out.println("");
		
		rectangle r2 = new rectangle();
		r2.setLenght(20);
		r2.setWidth(7);
		System.out.println("r2 area is " + r2.calculateArea());

	}

}
