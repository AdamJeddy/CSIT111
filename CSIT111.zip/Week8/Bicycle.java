package Week8;

public class Bicycle {
	private int speed;	// 0 to 5 
	private String colour;	// 1 to 5
	private int gear;	//
	private String type;	//
	
	Bicycle(){ //defult constructor
		speed = 0;
		gear = 0;
		colour = " ";
		type = " ";
	}
	
	Bicycle (int speed, int gear, String colour, String type){
		this.speed = speed;
		this.gear = gear;
		this.colour = colour;
		this.type = type;
	}
	
	void increase_speed(int n) {
		speed = speed + n;
		if (speed > 5) {
			speed = 5;
		}
	}
	
	void increase_gear(int n) {
		gear += gear + n;
		if (gear > 3) {
			gear = 3;
		}
	}
	
	void decrease_gear(int n) {
		gear = gear - n;
		if (gear < 1) {
			gear = 1;
		}
	}
	
	void increment_speed() {
		if (speed <= 4) {
			speed++;
		}
	}
	
	void decrement_gear() {
		if (gear >= 2) {
			gear--;
		}
	}
	
	void decrement_speed() {
		if (speed >= 2) {
			speed--;
		}
	}
	
	String tostring() {
		String s;
		s = "Speed = " + speed + " | Gear = " + gear + " | Type = " + type + " | Colour = " + colour;
		return s;
	}
	
}
