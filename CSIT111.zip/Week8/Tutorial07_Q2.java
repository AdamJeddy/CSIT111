package Week8;

import java.util.Scanner;

public class Tutorial07_Q2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		Employee e1;
		Employee e2;
		
		e1 = new Employee();
		e2 = new Employee("Sami", 1234, 2000, "Dubai");
		
		e1.setName("Adam");
		e1.setID(4321);
		e1.setSalaray(1000);
		e1.setAdd("UOWD");
		
		System.out.println(e1.getEmployeeInfo());
		System.out.println(e2.getEmployeeInfo());
		
		//int[] a = new int[3];//should be 10 but lowered it to test
		
		Employee[] employeelist = new Employee[3];//should be 10 but lowered it to test
		
		for (int i = 0; i < employeelist.length; i++) {
			//ask user for info
			System.out.println("Please enter Employee Information : ");
			System.out.print("Name: ");	String name = in.next(); 
			System.out.print("ID: ");	int id = in.nextInt(); 
			System.out.print("Salary: ");	double salary = in.nextDouble(); 
			System.out.print("Add: ");	String address = in.next(); 
			
			 System.out.println("");
			//Create Object type Employee
			Employee e = new Employee(name, id, salary, address);
			
			/* Another way to do it
			
			Employee emp = new Employee();
			emp.setName(name);
			emp.setID(id);
			emp.setSalaray(salary);
			emp.setAdd(address); */
			
			//Add Object e to array of Employee
			employeelist[i] = e;
		}
		
		
		for (int i = 0; i < employeelist.length; i++) {
			System.out.println(employeelist[i].getEmployeeInfo());
		}
		
	}

}
