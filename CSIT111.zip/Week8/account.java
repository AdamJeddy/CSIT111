package Week8;

import java.util.Date;

public class account {
	private int id = 0;
	private double balance = 0;
	private double annualInterestRate = 0;
	private Date dateCreated = new Date() ;
	
	//Constructors
	account() {
		//Defult account
	}
	
	account(int id, double b, double ai){
		this.id = id;
		this.balance = b;
		this.annualInterestRate = ai;
		//this.dateCreated = d;
	}
	
	//Getters / Accessor
	public int getID() {
		return id;
	}
	public double getBalance() {
		return balance;
	}
	public double getAnnualIn() {
		return annualInterestRate;
	}
	public double getMonthlyIn() {
		double monthly = annualInterestRate/12;
		return monthly;
	}
	public Date getdateCreated() {
		return dateCreated;
	}
	
	
	
	//Setters / Mutator
	public void withdraw(double x) {
		balance -= x;
	}
	
	public void deposit(double y) {
		balance += y;
	}
	
	
	//Method
	public String getAccountInfo() {
		String info;
		
		info = "ID: " +id+ " | Balance: AED" +balance+ " | Annual Interest:" +annualInterestRate+ "% | Date: " +dateCreated;
		return info;	
	}
	
}
