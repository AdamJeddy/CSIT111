package Week8;

public class Lecture8 {

	public static void main(String[] args) {
		// Class : 
		/*
		 * Class should contain:
		 * 	- member Data: Lname, Fname..... (usually are private)
		 * 	- Constructor ( No return type, public ), parameter constructor, defult const.
		 * 	- Methods e.g. toString, increase_speed
		 * 
		 * Object is an instance of a class
		 * 
		 *  ___________________
		 * |	Bycicle		   |
		 * |___________________|
		 * |Speed: 1;5		   |
		 * |Type: 2 types	   |
		 * |Couour: Red, Yellow|
		 * |___________________|
		 * |Constructor		   |
		 * |___________________|
		 */
		
		//Student is the class, A is the object, After Student is construct for H
		/*Student A = new Student ("Adam", "Ahsan", 18, "Indian");
		Student B = new Student ("Bob", "Kol", 20, "UAE");
		
		Student[] arr = {A,B}; //Declaration
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i].tostring());
		}*/
			
		Bicycle b1 = new Bicycle(1,2,"Black","Sport");
		Bicycle b2 = new Bicycle(0,1,"Blue", "Regular");
		Bicycle b3 = new Bicycle(5,3,"Red", "Mountain");
		Bicycle b4 = new Bicycle();
		
		b1.increase_speed(3);
		b2.increase_speed(2);
		b1.increase_gear(2);
		b2.decrement_speed();
		b1.decrement_gear();
		b1.increase_speed(10);
		
		//Bicycle [] arrb = {b1, b2, b3, b4};
		Bicycle []	arrb = new Bicycle [4];
		arrb[0] = b1;
		arrb[1] = b2;
		arrb[2] = b3;
		arrb[3] = b4;
		
		for (int k = 0; k < arrb.length; k++) {
			System.out.println(arrb[k].tostring());
		}
		
		
		
		
	}//main method

}//main class
