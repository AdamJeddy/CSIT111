package Week8;

public class Student {
	private String Lname;
	private String Fname;
	private int age;
	private String Nationality;
	
	
	public Student (String Lnam, String Fname, int age, String nat){
		Lname = Lnam;
		this.Fname = Fname;
		this.age = age;
		this.Nationality = nat;
	}//end of param. constructor
	
	String tostring() {
		String s = Lname + " " + Fname + " " + age + " " + Nationality;
		return s;
	}//end toString
	
}//class Student
