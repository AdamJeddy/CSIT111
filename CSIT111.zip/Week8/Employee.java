package Week8;

public class Employee {
	private String employeeName;
	private int ID;
	private double salary;
	private String address;
	
	//Constructor
	Employee(){
		
	}
	
	Employee(String n, int i, double s, String a){
		employeeName = n;
		ID = i;
		salary = s;
		address = a;
	}
	
	//Getters / Accessor
	public String getName() {
		return employeeName;
	}
	
	public int getID() {
		return ID;
	}
	
	public double getSalary() {
		return salary;
	}
	
	public String getAdd() {
		return address;
	}
	
	//Setters / Mutator
	public void setName(String n) {
		this.employeeName = n;
	}
	
	public void setID(int id) {
		this.ID = id;
	}
	
	public void setSalaray(double s) {
		this.salary = s;
	}
	
	public void setAdd(String a) {
		this.address = a;
	}
	
	
	//Method
	
	public String getEmployeeInfo() {
		String s;
		
		s = "Name: " + employeeName + " | ID: " + ID + " | Salary: " + salary + " | Address: " + address ; 
		
		return s;
	}
	
	
}
