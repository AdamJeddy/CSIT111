package Week8;

public class TestForAccount {

	public static void main(String[] args) {
		
		account object;
		
		object = new account(1522, 20000, 4.5);
		
		System.out.println("Origianl account info: ");
		System.out.println(object.getAccountInfo());		
		System.out.println("");
		
		object.withdraw(2500);
		object.deposit(3000);
		
		System.out.println("Account after Transfer: ");
		System.out.println(object.getAccountInfo());
		System.out.println("Balance: " +object.getBalance());
		System.out.println("Monthly Interest : " + object.getMonthlyIn() + "%");
		System.out.println("Date of creation of account: " + object.getdateCreated());
	}

}
