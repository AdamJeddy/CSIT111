package Week8;

public class ClassWork {

	public static void main(String[] args) {
		// Title(S), ISBN(I),	#_Copies(I), author_Name(S), publisher_Name(S)
		
		Book B1 = new Book("Invisible Man", 891830, 1, "Jeffrey Brown", "Akashic Books");
		Book B2 = new Book("Harry Potter", 60309, 10, "J. K. Rowling","Dzanc Books");
		Book B3 = new Book("Murder on Express", 60308,  8, "Agatha Christie","Graywolf Press");
		Book B4 = new Book("Romeo and Juliet", 60409, 7, "William Shakespeare","Hanging Loose");
		Book B5 = new Book("The Mist", 123830, 5, "Stephen King","Penguin Books");
		
		B1.decrement_copy();
		B1.decrement_copy();
		B2.increment_copy();
		B2.increment_copy();
		B3.decrement_copy();
		B4.increment_copy();
		B5.decrement_copy();
		
		Book[]	arrbook = new Book [5];
		arrbook[0] = B1;
		arrbook[1] = B2;
		arrbook[2] = B3;
		arrbook[3] = B4;
		arrbook[4] = B5;
		
		
		for (int i = 0; i < arrbook.length; i++) {
			System.out.println(arrbook[i].tostring());
		}//For end
		
		
	}

}
