package Week7;

import java.io.File;
import java.util.Scanner;

public class lecture7_1 {

	public static void main(String[] args) {
		/*File file = new File ("test.txt");
		Scanner sc = new Scanner(file);
		
		int[] arr = new int[1000];
		/*
		for (int i = 1; i <= 10; i++) 
			arr[k-1] = sc.nextInt();
			//display the array
			for (int i = 0; i < ; j++) 
				System.out.println(" "+arr[k]);
		
		int N = 0;
		while (sc.hasNextInt()) {
			arr[N] = sc.nextInt();
			N++;
		}//While End
		
		System.out.println("the numeber of data is = "+N);
		
		for (int l = 0; l < N; l++) {
			if (arr[l]%2 == 0) {
				System.out.println(" "+arr[l]);
			} 
			
		}*/
	}

}
