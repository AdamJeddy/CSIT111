package Week7;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class Lecture7 {

public static double convert_to_Celsius(double temp_f) {
	double temp_c = (5./9.)*(temp_f-32.);
	return temp_c;
}//End of Function

public static double cal_area(double radius) {
	double area = Math.PI*Math.pow(radius, 2);
	return area;
}
public static double cal_peri(double radius) {
	double perimeter = 2*Math.PI*radius;
	return perimeter;
}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
/*
		double temp_F;
		double temp_C;
		System.out.println("Enter temp. in Farenheit");
		
		temp_F = in.nextDouble();
		temp_C = 5./9.*(temp_F - 32);
		System.out.println("temp in Celsius : "+ temp_C);
		//declare the variables as int
		//reading the variable as int 
*/
		
/*		
		System.out.println("Enter two numbers a & b : ");
		double a, b; 
		a = in.nextDouble();
		b = in.nextDouble();
		double c = (a/b);
		System.out.println("Result a/b: "+c);
*/
	
/*
		double temp_f;
		double temp_c;
		
		String Far_str = JOptionPane.showInputDialog("Enter temp in far");
		temp_f = Double.parseDouble(Far_str);//Converts string to double
		System.out.println("Temp in Farenhite = "+temp_f);
		
		temp_c = (5./9.)*(temp_f-32.);
		//String temp_c_str = "temperature in Celsius : "+temp_c;
		//JOptionPane.showConfirmDialog(null, temp_c_str);
		JOptionPane.showConfirmDialog(null, "temperature in Celsius : "+temp_c);
*/		

/* */
		//write a function I gave a radius, itgives me back the area of the circle
		//also the perimeter
		
		String radius_str = JOptionPane.showInputDialog("Enter radius : ");
		double radius = Double.parseDouble(radius_str);
		double area = cal_area(radius);
		
		JOptionPane.showMessageDialog(null, "Area of the circle : "+area);
		
		double perimeter = cal_peri(radius);
		JOptionPane.showMessageDialog(null, "Perimeter of the circle : "+perimeter);
		

	}

}
