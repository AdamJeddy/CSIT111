package Week7;

import java.util.Scanner;

public class Tutotrial06 {
	
/*Question 1 : Write a program to print the circumference and return area of a circle of radius 
entered by user by defining your own method.*/
	public static double Circle() {
		Scanner in = new Scanner(System.in);
		
		int radius;
		System.out.print("Enter the radius : ");
		radius = in.nextInt();
		
		double circum = 2 * Math.PI * radius ;
		System.out.print("Circumference is = "+circum);
		
		double area = Math.PI * radius * radius ;
		
		System.out.println("");
		in.close();
		return area;
	}
	
/*Question 2 : Define two methods to print the maximum and the minimum number respectively 
among three numbers entered by user.*/
	public static int max() {
		Scanner in = new Scanner(System.in);

		int num1, num2, num3 ;
		System.out.println("Enter 3 numbers : ");
		num1 = in.nextInt();
		num2 = in.nextInt();
		num3 = in.nextInt();
		
		int m;
		if (num1 >= num2 && num1 >= num3) {
			m = num1;
		} 
		else if (num2 >= num1 && num2 >= num3){
			m = num2;
		}
		else {
			m = num3;
		}
		
		System.out.println("");
		in.close();
		return m;
	}
	public static int min() {
		Scanner in = new Scanner(System.in);

		int num1, num2, num3 ;
		System.out.println("Enter 3 numbers : ");
		num1 = in.nextInt();
		num2 = in.nextInt();
		num3 = in.nextInt();
		
		int m;
		if (num1 <= num2 && num1 <= num3) {
			m = num1;
		} 
		else if (num2 <= num1 && num2 <= num3){
			m = num2;
		}
		else {
			m = num3;
		}
		
		
		System.out.println("");
		in.close();
		return m;
	}
	
/*Question 2 : A person is eligible to vote if his/her age is greater than or equal to 18. 
 Define a method to find out if he/she is eligible to vote.*/
	public static boolean vote() {
		Scanner in = new Scanner(System.in);
		
		int age ;
		System.out.print("Enter your age : ");
		age = in.nextInt();
		
		if (age >= 18) {
			System.out.println("");
			in.close();
			return true;
		} else {
			System.out.println("");
			in.close();
			return false;
		}

	}

/*Define a method that returns the volume of the cylinder. The radius and the length of the 
cylinder are entered by user. Volume = PI * radius2 * length */
	public static double Volume1() {
		Scanner in = new Scanner(System.in);
		System.out.println("Finds Volume : ");
		
		int radius;
		System.out.println("Enter the radius : ");
		radius = in.nextInt();
		
		int lenght;
		System.out.println("Enter the lenght : ");
		lenght = in.nextInt();
		
		
		double Volume = Math.PI *Math.pow(radius, 2)* lenght;
		System.out.print("Circumference is = "+Volume);
				
		System.out.println("");
		in.close();
		return Volume;
	}
	public static double Volume2(int radius, int lenght){
			double v = 3.14*radius*radius*lenght;
			
			return v;
	}
	
/*The method should return the profit in AED.  Profit =   R*Q  - (  VC*Q - FC) */
	public static double Profit() {
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter the marginal variable cost (VC), fixed cost (FC), marginal revenue (R) and the quantity solde (Q)");
		int vc = in.nextInt();
		int fc = in.nextInt();
		int r = in.nextInt();
		int q = in.nextInt();
		
		double p = r*q - (vc*q - fc);
		
		in.close();
		return p;
	}
	
/* Define a method that returns the minimum of an 1D array */
	public static int minArr(int a[]) {
		// 3,8,5,2,9
		int min = a[0];//3
		for (int i = 1; i < a.length; i++) {
			if (min > a[i]) {
				min = a[i];
			}
		}
		
		return min;
	}

/*
 * Define a method that returns the variance of 1D array 
 * Step 1: Average = Calculate the average of your array
 * Step 2: Sum all (a[i] - average) * (a[i] - average)
 * Step 3: Divide sum/(array lenght - 1)
 */
	public static double Variance(int arr[]) {
			
		int sumCount = 0;
		for (int i = 0; i < arr.length; i++) {
			sumCount += arr[i];
		}
		double Average = sumCount/arr.length;
		
		double Sum = 0;
		for (int i = 0; i < arr.length; i++) {
			Sum += (arr[i] - Average) * (arr[i] - Average);
		}
		
		double var = Sum/(arr.length - 1);
		
		return var;
		
	}
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		//Question 1 
		double a = Circle();
		System.out.println("Area is : " + a);
		System.out.println("");
		
		//Question 2
		int n = max();
		System.out.print("Max number is : " + n);
		System.out.println("");
		
		int m = min();
		System.out.print("Min number is : " + m);
		System.out.println("");
		
		
		//Question 3
		boolean v = vote();
		if (v == true) {
			System.out.println("Yes, you are eligeble to vote");
		} else {
			System.out.println("No, you are not eligeble to vote");
		}
		System.out.println("");
		
		
		//Question 4_Type1
		double vol1 = Volume1();
		System.out.println("Volume is : " + vol1);System.out.println("");
		
		//Question 4_Type2
		System.out.println("Finds Volume : ");
		
		int radius;
		System.out.print("Enter the radius : ");
		radius = in.nextInt();System.out.println("");
		
		
		int lenght;
		System.out.print("Enter the lenght : ");
		lenght = in.nextInt();System.out.println("");
		
		
		double vol2 = Volume2(radius, lenght);
		System.out.print("Volume : " + vol2);System.out.println("");
		
		
		//Question 5
		double p = Profit();
		System.out.println("Profit is : " + p);
		
		
		//Question 6
		int arr[] = {3, 5, 6, 9, 2};
		System.out.println("List of numbers : 3, 5, 6, 9, 2");
		
		int minInt = minArr(arr);
		System.out.println("Minimum number from the list is : " + minInt);
		
		
		//Question 9
		int arr2[] = {1,2,3,4,5};
		double var2 = Variance(arr2);
		System.out.println(var2);
		
		in.close();
	}
}
