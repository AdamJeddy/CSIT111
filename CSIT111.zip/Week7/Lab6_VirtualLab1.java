package Week7;

public class Lab6_VirtualLab1 {

	public static void main(String[] args) {
		String str = "This Is A String";
		System.out.println("Test Case: "+str);
		System.out.println("");
		
		
		System.out.println("Task 1: Change Test case to All lowercase");
		
		System.out.print("All lowercase: ");
		for (int i = 0; i < str.length(); i++) {
			int value = str.charAt(i);
			
			if (value > 64 && value < 91) {
				value += 32;
			}//If End
			char finalValue = (char) value;
			System.out.print(finalValue);
		}//For End
		System.out.println("");System.out.println("");

		
		
		
		System.out.println("Task 2: Change Test case to All Uppercase");

		System.out.print("All Uppercase: ");
		for (int i = 0; i < str.length(); i++) {
			int value = str.charAt(i);
			
			if (value > 96 && value < 123) {
				value -= 32;
			}//If End
			char finalValue = (char) value;
			System.out.print(finalValue);
		}//For End
		System.out.println("");System.out.println("");
		
		
		
		
		String str2 = "6724395 AdamAhsan aa923";
		System.out.println("Test String: "+str2);
		System.out.println("Task 3: Add all numbers from the Test String");
		
		int result = 0;
		for (int k = 0; k < str2.length(); k++) {
			int value = str2.charAt(k);
			
			if (value > 47 && value < 58) {
				value = value - 48;
				result += value;
			}//If End
		}//For End
		
		System.out.println("Sum of all the numbers in the String: " + result);
	}

}
