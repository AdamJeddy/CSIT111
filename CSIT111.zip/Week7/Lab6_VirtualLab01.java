package Week7;

public class Lab6_VirtualLab01 {

	public static void main(String[] args) {
		String str2 = "6724395 AdamAhsan aa923";
		System.out.println("Test String: "+str2);
		System.out.println("Task 3: Add all numbers from the Test String");
		
		int result = 0;
		for (int k = 0; k < str2.length(); k++) {
			int value = str2.charAt(k);
			
			if (value > 47 && value < 58) {
				System.out.println(value);
				result += value;
			}//If End
			
		}//For End
		
		System.out.println("Sum of all the numbers in the String: " + result);
	}

}
