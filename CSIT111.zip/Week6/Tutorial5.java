package Week6;

import java.util.Scanner;

public class Tutorial5 {

	public static void main(String[] args) {
		////	continuing from the last tutorial	////
//		__________________________________________________________________________________________________________________
		
		////	Question 9	////
		System.out.println("----- QUESTION 9 -----");
		/* Read a-b-c , calculate b^2-4ac and then use "Switch Case" for if the answer is negative, positive and equal */
		Scanner in = new Scanner(System.in);//Declare Scanner
		
		System.out.println("This Program Calculates Descriminant uses the Values which you input");
		System.out.println("");
		
		System.out.print("Enter the value for A : ");
		double a = in.nextDouble();
		if 	(a == 0 ) {
			while (a==0) {
				System.out.print("Zero cant be entered as A, Reinput the value : ");
				a = in.nextDouble();
				System.out.println("");
			}
		}
		System.out.print("Enter the value for B : ");
		double b = in.nextDouble();
		System.out.print("Enter the value for C : ");
		double c = in.nextDouble();
		System.out.println("");
		
		double det = b * b - 4.0 * a * c;
		//double det = Math.pow(b, 2) - 4.0 * a * c;
		//double det2 = -4*a*c;
		//double det = det1 + det2;
		
		System.out.println("Your Descriminanat is : "+det);
		
		// Read the value and assess it 
		int result ;
		if (det == 0) {
			result = 0;
		}
		else if ( det > 0 ){
			result = 1;
		}
		else {
			result = -1;
		}
		
		switch (result) {
			case 1 :
				double r1 = (-b + Math.pow(det, 0.5)) / (2.0 * a);
				double r2 = (-b - Math.pow(det, 0.5)) / (2.0 * a);
				System.out.println("We have 2 real solutions (Roots) X = "+r1+" and "+r2);
				break;
			case 0 :
				r1 = -b / (2.0 * a);
				System.out.println("The Root is : "+r1);
				break;
			case -1 :
				System.out.println("The equation has no real roots.");
		}
		System.out.println("");
	
//		__________________________________________________________________________________________________________________
		
		////	Question 9	////
		System.out.println("----- QUESTION 10 -----");
		/*	Read 3 inputs from the user and display them in ascending order	*/
		System.out.println("Enter 3 numbers : ");
		System.out.print("1 : ");
		double q10_1 = in.nextDouble();
		System.out.print("2 : ");
		double q10_2 = in.nextDouble();
		System.out.print("3 : ");
		double q10_3 = in.nextDouble();
		
		if (q10_1 < q10_2) {// if 1st is smaller then 2nd
			if (q10_1 < q10_3) {// 1st is the smaller than 2nd but is 1st smaller than 3rd
				if (q10_2 < q10_3) {// 1st is the smallest,	if 2nd is smaller than 3rd
					System.out.println("The ascending order is : "+q10_1+" "+q10_2+" "+q10_3);
				}
				else {// 1st is the smallest,	if 3rd is smaller than 2nd
					System.out.println("The ascending order is : "+q10_1+" "+q10_3+" "+q10_2);
				}
			}
			else {//1st is the smaller than 2nd but not 3rd thus 3rd is the smallest 
				System.out.println("The ascending order is : "+q10_3+" "+q10_1+" "+q10_2);
			}
		}
		else if (q10_2 < q10_1) {// is 2nd smaller than 1st
			if (q10_2 < q10_3) {// 2nd is smaller than 1 , but is it smaller than 3rd
				if (q10_3 < q10_1) {
					System.out.println("The ascending order is : "+q10_2+" "+q10_3+" "+q10_1);
				}
				else {
					System.out.println("The ascending order is : "+q10_2+" "+q10_1+" "+q10_3);
				}
			}
			else {
				System.out.println("The ascending order is : "+q10_3+" "+q10_2+" "+q10_1);
			}
		}
		else if ( q10_3 < q10_1) {
			if (q10_3 < q10_2) {
				if (q10_1 < q10_2) {
					System.out.println("The ascending order is : "+q10_3+" "+q10_1+" "+q10_2);
				}
				else {
					System.out.println("The ascending order is : "+q10_3+" "+q10_2+" "+q10_1);
				}
			}
			else {
				System.out.println("The ascending order is : "+q10_2+" "+q10_3+" "+q10_1);
			}
		}
		System.out.println("");
		
		
//		__________________________________________________________________________________________________________________
		
		////	Question 13		////
		System.out.println("----- QUESTION 13 -----");
		//System.out.println("");
		
		
		System.out.print("Please enter a size of array : ");
		int size;//Declare Size
		size = in.nextInt();//Store size
		
		int arr [] = new int [size];//Create array with size
		
		for (int i = 0; i < arr.length; i++) { //Let user input the values of the array positions 
			System.out.print("Please enter number for postion "+i+" : ");
			arr[i] = in.nextInt();
		}
		
		
		for (int i = arr.length-1; i >= 0; i--) {// make it backwards and output it 
			System.out.println("The array backwards is : ");
			System.out.println(arr[i]);
		}
	}

}
