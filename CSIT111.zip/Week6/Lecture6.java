package Week6;

public class Lecture6 {
	/** Functions 
	 * public static returnType nameFunction (input/argument/parameter) */ 
	 ////	1. Factorial ////
	public static int factorial (int num) {
		
		int fact = 1;
		if (num == 0 || num == 1) return 1;
		
		for (int i = 1; i <= num ; i++ )
			fact = fact * i;
		
		return fact;
	}//End of Function
	
	
	//// 2. Sum of Even	////
	public static int calculateSum(int [] arr){
		int sum = 0;
		
		for (int i = 0; i <arr.length; i++)
			sum = sum + arr[i];
		
		return sum;
	}//End of Function 2
	
	
	//// 3. Calculate Sum Even	////
	public static int sumEven(int [] arr) {
		int sum = 0;
		
		for (int i = 0; i < arr.length; i++ ) {
			if (arr[i]%2 == 0) {
				sum = sum +arr[i];
			}//End of If
		}//End of For
		
		
		return sum;
	}//End of Function 3
	
	
	//// 4. Are all Even ////
	public static boolean areAllEven(int [] arr) {
		int sum = 0;
		
		for (int i = 0; i < arr.length; i++ ) {
			if (arr[i]%2 == 0) {
				sum = sum +arr[i];
			}//End of If
		}//End of For
//		for (int i = 0; i < arr.length; i++ ) {
//			if (arr[i]%2 != 1) {
//				System.out.println("Not all of them are Even");
//				return false;
//			}//End of If
//			else {
//				sum = sum +arr[i];
//			}
//		}//End of For
		
		return true;
	}//End of Function 4
	
	
	public static void main(String[] args) {
		////	Test cases for Function 1	////
		System.out.println(factorial(1));
		System.out.println(factorial(2));
		System.out.println(factorial(3));
		System.out.println(factorial(4));
		System.out.println(factorial(5));
		////	End of Test Cases	////
		
		
		
		////	Test cases for Function 2	////
		int [] array1 = {2,4,3,1};
		//System.out.println(calculateSum("Sum of array 1 = "+array1));
		int [] array2 = {2,4};
		//System.out.println(calculateSum("Sum of array 2 = "+array2));
		////	End of Test Cases	////
		
		
		
		////	Test cases for Function 3	////
		int sumEven1 = sumEven(array1);
		System.out.println("Sum of all Even numbers is : "+sumEven1);
		int sumEven2 = sumEven(array2);
		System.out.println("Sum of all Even numbers is : "+sumEven2);
		////	End of Test Cases	////
		
		
		
		////	Test cases for Function 4	////
		boolean areEven1 = areAllEven(array1);
		System.out.println("Is all of Array 1 Even numbers : "+areEven1);
		boolean areEven2 = areAllEven(array2);
		System.out.println("Is all of Array 2 Even numbers : "+areEven2);
		////	End of Test Cases	////
		
		
	}

}
