package Week6;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Lab5 {
	
/** Functions:	public static returnType nameFunction (input/argument/parameter) */
	
// Function that returns true if word is Pali. and false if it isnt
    static boolean isPalindrome(String word) {  
    	int j = word.length(); 
  
        for (int i = 0; i < j; i++) { 
        	
            if (word.charAt(i) != word.charAt(j - 1)) 
                return false; 
            j--;
        } 
        
        return true; 
    } 
    
//Funtion that reverses text
  	public static char[] reverseFull(char[] array) {
  		int left, right;
          right = array.length-1;
    
          for (left = 0; left < right ; left++ ,right--) { 
              // Swap values of left and right 
              char temp = array[left]; //Temporary saves the value of the left letter
              array[left]  = array[right]; //Assigns right to left. so now left letter is the right one
              array[right] = temp; //Assigns left to right from the temp we saved. so now right letter is the left one
          }//For End
  		return array;
      }
  	
//Function that finds occurrence of a word in the string 	
  	public static int wordCounter(String str, String WordP3) {
  		//Split the String into a words array
  	    String a[] = str.split(" "); 
  	  
  	    //Search for the occurrences of a word 
  	    int wordCount = 0; 
  	    for (int i = 0; i < a.length; i++){//For loop for every word in the array 
  	    // if match found increase count 
	  	    if (WordP3.equals(a[i])) { //Checks both the words
	  	    	wordCount++;//Adds a count if the word is the same
	  	    }//If end
  	    }//For end 
  	  
  	    return wordCount;//Returns the value (the number of time the word was said)
  	}
//Function that finds and replaces words in the string 
  	public static String stringSwitch(String OldWord, String NewWord, String str) {
  	//Split the String into a words array
  	    String a[] = str.split(" "); 
  	  
  	    //Search for the occurrences of the old word 
  	    for (int i = 0; i < a.length; i++){//For loop for every word in the array 
  	    // if match found increase count 
	  	    if (OldWord.equals(a[i])) { //Checks if its the old word
	  	    	a[i] = NewWord;
	  	    }//If end
  	    }//For end 
  	    
  	    String NewString = "";
  	    
  	    for (int x = 0; x < a.length; x++) {
  	    	NewString += a[x] + " ";
  	    }
  	  
  	    return NewString;//Returns the value (the number of time the word was said)
  	}
  	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);// Import Scanner
		
		
		

		System.out.println("_____________________________________________________________");
		//Part 1
		System.out.println("This program finds all palindromes within the text entered by the user"); System.out.println("");
		
    	int CountOfPlaindromes = 0;
		String word = null;
		
		String str = JOptionPane.showInputDialog("Enter a String of text : ");/*Ask User to Enter input*/
		
		//System.out.print("Enter a String of text : "); 
		//String str = in.nextLine(); //Declare and Store the input in variable
		
		str = str + " ";//Adds a space in the end of the String so the last word isnt left oout
		
    	//For loop to count the number of Palindromes
    	for (int i = 0; i < str.length(); i++) {
    			char ch = str.charAt(i);//Stores the value of alphabet on index i in ch
    			
    			//Extracted each word 
    			if (ch != ' ') {
    				word = word + ch;
    			}//If end
    			else {
    				if (isPalindrome(word)) {
    					CountOfPlaindromes++;
    				}//If End
    				word = "";//Reassign the variable "word" for the next word
    			}//Else end
    	}//For end
    	
    	JOptionPane.showMessageDialog(null, "There's "+CountOfPlaindromes+" Palidrome/s in the string you entered");//, null, JOptionPane.INFORMATION_MESSAGE
    	
		System.out.println("There's '"+CountOfPlaindromes+"' Palidrome/s in the string you entered");System.out.println("");

		
//________________________________________________________________________________________________________________________________________________________
		
			
		System.out.println("_____________________________________________________________");
		
		//Part 2
		System.out.println("This program reverses all text, or parts of specified between two words"); System.out.println("");
		
		char[] array = str.toCharArray(); //changes 'str'(input) to an array of characters
        

		array = reverseFull(array);//Call program for reversing the input

		System.out.println("The reverse of the whole String is : ");
        for(char c: array){ //Loop for displaying the result
            System.out.print(c); 
        }//For End
        System.out.println("");

		
//________________________________________________________________________________________________________________________________________________________
      			
      		
		System.out.println("_____________________________________________________________");
		
		//Part 3
		System.out.println("This program finds a specific word and counts the occurrence of it, entered by the user"); System.out.println("");
	    
	    //Ask user for a word for counting an occurrence
	    System.out.print("Enter a word to find the occurrence of it in the string: ");
	    String WordP3 = in.nextLine();
	    
	    System.out.println("The word "+WordP3+" occurrs this many times : "+wordCounter(str, WordP3));
	    

//________________________________________________________________________________________________________________________________________________________
	        		
	        		
  		System.out.println("_____________________________________________________________");
  		//Part 4
  		System.out.println("This program replaces words in the String"); System.out.println("");
  		
  		String OldWord, NewWord;
  		
  		//Ask user for the 'word' whcih have to be replaced 'with what'
  		System.out.print("Which word do you wanna replace: ");
  		OldWord = in.nextLine();
  		
  		System.out.print("With what word: ");
  		NewWord = in.nextLine();
  		
  		System.out.println(stringSwitch(OldWord, NewWord, str));
  		
  		

	}

}
