package Week6;

import java.util.Scanner;

public class Test {
	
public static void main(String[] args) {  
	
	Scanner in = new Scanner(System.in);
	
	//________________________________________________________________________________________________________________________________________
			
			//Task 1 
			System.out.println("Task 1 : Housing Cost");
			
	
		   
	}  
}  