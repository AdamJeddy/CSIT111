package Week10;

import java.io.*;
import java.io.BufferedReader;
import java.lang.reflect.Array;
import java.util.Scanner;

public class MidtermReview {
	public static boolean isEqual(int arr1[], int arr2[]) {
		if (arr1.length != arr2.length) {
			return false;
		}
		
		for (int i = 0; i < arr1.length; i++) {
			if (arr1[i] != arr2[i]) {
				return false;
			}
		}
		
		return true;
	}
	
	public static boolean isPrime(int num) {
		
		for (int i = 2; i < num;i++) {
			
			if (num % i == 0) {
				return false;
			}//If end
			
		}//For end
		
		return true;
	}

	public static int arrSum(int arr[]) {
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			sum += arr[i];
		}
		return sum;
	}
	
	public static int arrSumEven(int arr[]) {
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] % 2 == 0) {
				sum += arr[i];
			}//if end
		}//For end
		return sum;
	}
	
	public static void main(String[] args) throws FileNotFoundException {
		Scanner in = new Scanner(System.in);
		/*
		//Qusetion 1 - 5:55
	//Test Cases
		int arr1[] = {1,2,3,4,5};
		//int arr1[] = {1,2,3,4,5,6};
		//int arr1[] = {1,3,4,5,6};
		int arr2[] = {1,2,3,4,5};
	//
		
		boolean result = isEqual(arr1, arr2);
		if (result == true) {
			System.out.println("All values are equal");
		}//If end
		else {
			System.out.println("Value are not same");
		}//Else end
		System.out.println("");
		
		
		
		
		//Question 2 - 16:09 (10:14)
		
		int prime1 = 4;
		int prime2 = 7;
		
		boolean isprime1 = isPrime(prime1);
		boolean isprime2 = isPrime(prime2);
		
		System.out.println("Prime 1 is "+ isprime1);
		System.out.println("Prime 2 is "+ isprime2);
		System.out.println("");
		
		
		
		
		//Qestion 3 - 23:53 (8:02)
		
		int countT3 = 0;
		int sumT3 = 0;
		int tempT3 = 0;
		boolean temp_T3;
		
		for (int i = 2; countT3 < 20; i++) {
			tempT3 = i;
			temp_T3 = isPrime(tempT3);
			
			if (temp_T3 == true) {
				sumT3 += tempT3;
				countT3++;
				System.out.println(i);
			}//If end
			
		}//For end
		
		System.out.println("sum of first 20 prime numbers: "+sumT3);
		System.out.println("");
		
		
		
		
		//Question 4 - 28:23 (4:30)
		
		System.out.println("Write to check how many prime no.s are > that: ");
		int max = in.nextInt();
		int counterT4 = 0;
		
		for (int j = 2; j < max; j++) {
			if (isPrime(j) == true) {
				counterT4++;
			}
		}
		
		System.out.println("Total number of prime numbers below "+max+" is "+counterT4);
		
		
		
		
		//Question 5 - 57:58 (29:35)
		System.out.println("Write a number for showing its sum: ");
		int num5 = in.nextInt();
		int calNum = num5;
		int temp5 = num5;
		int count5 = 1000;
		int sum5 = 0;
			
			for (int i = 0; i < 4 ; i++) {
				temp5 = calNum/ count5;
				sum5 = sum5 + temp5;
				calNum %= count5;
				count5 /= 10;
			}
			
			System.out.println("");
		System.out.println("Sum of "+num5+" is: "+sum5);
		
		System.out.println("");
		System.out.println("Version 2 of the task");
		
		System.out.println("Enter a number for its own sum: ");
		int num5_1 = in.nextInt();
		String value5 = String.valueOf(num5_1);
		int sum = 0;
		
		for (int p = 0; p < value5.length(); p++) {
			sum += (value5.charAt(p)- 48);
		}
		
		System.out.print(sum);
		
		
		
		
		//Question 7 - 1:10:55 (13:03)
		File q7 = new File("Q7.txt");
		Scanner read7 = new Scanner(q7);
		int temp7 = 0;
		
		while (read7.hasNext()) {
			temp7 = read7.nextInt();
			if (temp7 % 2 == 1) {
				System.out.println(temp7);
			}//If end
				read7.hasNextLine();
		}//While end
		
		
		
		
		//Question 8 - 1:35:43 (24:48)
		File q7 = new File("Q7.txt");
		Scanner read8 = new Scanner(q7);
		int arr[] = new int[10];
		int counter8 = 0;
		int temp8 = 0;
		
		while (read8.hasNext()) {
			if (read8.hasNextInt()) {
				temp8 = read8.nextInt();
				arr[counter8] = temp8;
				counter8++;
			}//IF end
			else {
				read8.hasNextLine();
			}//Else end
		}//While end

		for (int T = 0; T < arr.length; T++) {
			System.out.println(arr[T]);
		}
		
		
		
		
		//Question 9 - 1:39:36 (3:53)
	//Test cases
		int arr9[] = {1,2,3,4,5};
		int arr9_1[] = {10,10,10,10};
		
		System.out.println("Sum of arrays : "+arrSum(arr9));
		System.out.println("Sum of arrays : "+arrSum(arr9_1));
		
		
		
		
		//Question 9 - 1:43:26 (3:50)
	//Test cases
		int arr9[] = {1,2,3,4,5,6};
		int arr9_1[] = {1,3,5,7};
		
		System.out.println("Sum of arrays even : "+arrSumEven(arr9));
		System.out.println("Sum of arrays even : "+arrSumEven(arr9_1));

		
		
		
		//Question 10 - 1:46:43 (3:17)
		System.out.println("Enter a number to sum it till then : ");
		int num10 = in.nextInt();
		int sum10 = 0;
		
		for (int v = 0; v < (num10+1); v++) {
			sum10 += v;
		}
		
		System.out.println("Number sum till "+num10+" is : "+sum10);
		
		
		
		
		//Question 11 - 1:50:00
		//Question 14 - 1:54:31 (4:31)
		System.out.println("Enter a number: ");
		int N = in.nextInt();
		int tmpN = N;
		
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < tmpN; j++) {
				System.out.print("* ");
			}//For end
			tmpN--;
			System.out.println("");
		}
		
		
		
		
		//Question 15 - 1:55:26 (0:57)	
		System.out.println("Enter a number: ");
		int N2 = in.nextInt();
		int tmpN2 = 1;
		
		for (int i = 0; i < N2; i++) {
			for (int j = 0; j < (tmpN2*2); j++) {
				System.out.print("* ");
			}//For end
			tmpN2++;
			System.out.println("");
		}
			*/	
		
		//Question 16			
//		boolean a, b, c;
//        a = b = c = true;
//
//        if( !a || ( b && c ) )    // false or true           true    if exceuted
//        {
//            System.out.println("If executed");
//        }
//        else
//        {
//            System.out.println("else executed");
//        }
		//Write the Java code for a function that has as inputs 
		//an integer array and a given integer number and returns
		//true if the integer number is an element of the array 
		//otherwise it returns false

		int array[] = {1,2,3,4,5};
		int counter = 0;
		
		for (int i = 0; i < array.length; i++) {
			if (isPrime(array[i])) {
				counter++;
			}
		}
		System.out.println("Number of prime numbers: "+counter);
		
		
		
		
		
	}

}
