package Week10;

public class tut9_Product {//We put them in private for data hiding (security)
// Member data	attribute
	int product_id;
	private String prod_name;
	private String prod_detail;
	private double prod_price;
	
	/* What is  constructor? What are its special properties?
	 * Ans: It is a metod that allows to create an instance of the class.
	 * 		That creating an object.
	 * 		Same name as the class
	 * 		No return type
	 * 		It is different than void
	 */
	
	tut9_Product()	{
		
	}
	
	tut9_Product(int id, String name, String detail, double price){
		product_id = id;
		this.prod_name = name;
		prod_detail = detail;
		prod_price = price;
	}
	
	void display() {
		System.out.println("Product ID: "+product_id+"	| Name: "+prod_name+"	| Detail: "+prod_detail+"	| Price: "+prod_price);	
	}
	
	public String toString() {
		String str = "Product ID: "+product_id+"	| Name: "+prod_name+"	| Detail: "+prod_detail+"	| Price: "+prod_price;
		return str;
	}
	
	int get_id(){
		return product_id;
	}
}
