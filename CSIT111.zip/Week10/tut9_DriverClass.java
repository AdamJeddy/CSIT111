package Week10;

import java.io.File;
import java.util.Scanner;

public class tut9_DriverClass {
	/*
	 * Static variable?
	 * Ans: It is recognised only in the scope of a method
	 * 
	 * Static Method
	 * Ans
	 * 
	 * Describe concept of Stream?
	 * Ans: A sequence of characters
	 */
	
	static void display_list(tut9_Product arr[]) {
		for (int i = 0; i < 2; i++) {
			System.out.println(arr[i].toString());
		}//For end
	}
	
	static int search_by_id(tut9_Product [] arr, int id) {
		
		for (int i = 0; i < 2; i++) {
			if (arr[i].get_id() == id) {
				return i;
			}
		}
		
		return -1;
	}// Search_by_id

	public static void main(String[] args) throws Exception {
		//File myfile = new File("tut9.txt");
		//Scanner inf = new Scanner(myfile);
		Scanner inf = new Scanner(new File("tut9.txt"));//A single line
		
		tut9_Product[] list = new tut9_Product[5];
		
		tut9_Product p1 = new tut9_Product(9989, "Milk", "this is ordered once a month", 12);
		list[0] = p1;
		
		list[1] = new tut9_Product(1256, "Bread", "Flour", 5);
		
		display_list(list);
		
		
		System.out.println("");
		int index = search_by_id(list, 9989);
		if (index != -1) {
			System.out.println(list[index].toString());
		}
		else {
			System.out.println("Product doesnt exist");
		}
		
		int index1 = search_by_id(list, 999);
		if (index1 != -1) {
			System.out.println(list[index1].toString());
		}
		else {
			System.out.println("Product doesnt exist");
		}
	}

}
