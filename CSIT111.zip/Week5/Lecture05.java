package Week5;

import java.util.Scanner;

//import java.util.Scanner;

public class Lecture05 {

//	@SuppressWarnings("resource")
	public static void main(String[] args) {
////_____________________________________________________________		
		
		
		for (int i = 3; i <= 20;i=i+2 ) {
			System.out.print("i = "+i+"   ");
			
			if ( i==13 || i==11 || i==9 ) continue;
			System.out.println("i = "+i);
		}
		System.out.println("");
////_____________________________________________________________	
		
		// Reading a value for a Season
		Scanner in =new Scanner(System.in);
		System.out.println("Enter a number for a Season: ");
		int Season = in.nextInt();
		
		switch (Season) {
		case 1 : System.out.println("Season is Fall"); break;
		case 2 : System.out.println("Season is Winter"); break;
		case 3 : System.out.println("Season is Spring"); break;
		case 4 : System.out.println("Season is Summer"); break;
		default : System.out.println("Error: Invalid input");
		}
		System.out.println("");
////_____________________________________________________________
		
		//Reading a value for a Month
		System.out.println("Enter a number for a Month: ");
		int Month = in.nextInt();
		
		switch (Month) {
		case 1 : System.out.println("Month is January"); break;
		case 2 : System.out.println("Month is Febuary"); break;
		case 3 : System.out.println("Month is March"); break;
		case 4 : System.out.println("Month is April"); break;
		case 5 : System.out.println("Month is May"); break;
		case 6 : System.out.println("Month is June"); break;
		case 7 : System.out.println("Month is July"); break;
		case 8 : System.out.println("Month is August"); break;
		case 9 : System.out.println("Month is September"); break;
		case 10 : System.out.println("Month is October"); break;
		case 11 : System.out.println("Month is November"); break;
		case 12 : System.out.println("Month is December"); break;
		default : System.out.println("Error: Invalid input");
		}
		System.out.println("");
////_____________________________________________________________
		
		//Make and Read from an array 
		int [] arr = {1, 3, 5, 7};
		System.out.println("The lenght of the array is: "+arr.length);// Prints out the length of the array
		System.out.println("Array 1: ");
		
		for (int i=0; i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
		
		System.out.println("");
//_____________________________________________________________		
		
		//Double old Array without initializing it 
		//int [] arr2 = new int [4]; is another way but is not good
		int [] arr2 = new int [arr.length];
		System.out.println("Array 2: ");
		
		for (int k = 0; k<arr2.length;k++) {
			arr2[k] = 2*arr[k];
			System.out.println(arr2[k]);
		}
		System.out.println("");
//_____________________________________________________________
		
		//Read 6 numbers (Store them), Find the sum of the even numbers (and display them)
		int sum = 0;
		int [] arr3 = new int [6];
		
		for(int x = 0; x<=arr3.length-1;x++){
			System.out.println("Enter number for index "+x+" :");
			arr3[x] = in.nextInt();
		}
		
		for(int x = 0; x<=arr3.length-1;x++) {
			if(arr3[x]%2==0) {
				sum = sum + arr3[x];
			}
		}
		System.out.println("The sum of even numbers from Array 3 is : "+sum);
		in.close();
	}
}
