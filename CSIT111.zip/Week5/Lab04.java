package Week5;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Lab04 {
	public static void main(String[] args) {
	Scanner in = new Scanner(System.in);
//	______________________________________________________________
	System.out.println("____Task 1____");
	System.out.println("Task: Generate a random number between 1-10 and square and cube it.");
	System.out.println("");
	
	System.out.print("Enter a value: ");
	int size = in.nextInt();//storing the value
	
	int randomNumber[] = new int [size];//making the array with the user input
	Random rand = new Random();
	int SquareNums[] = new int [size];
	
	for (int i = 0; i < randomNumber.length; i++) {
		randomNumber[i] = rand.nextInt(10);
		System.out.println("The Number is: "+randomNumber[i]);
		
		SquareNums[i] = (int) Math.pow(randomNumber[i], 2);
		System.out.println("The square is: "+SquareNums[i]);
		
		SquareNums[i] = (int) Math.pow(randomNumber[i], 3);
		System.out.println("The cube is: "+SquareNums[i]);

		System.out.println("");
	}		
	
//	______________________________________________________________
	/*find the smallest among the list of No. entered by the user. user decides the No. of values in the list.*/
	System.out.println("____Task 2____");
	System.out.println("Task: Find the smallest number entered by the user");
	System.out.println("");
	
	//Get the size of the array from the user
	System.out.print("Enter the size of array : ");
	int size2 = in.nextInt();
	
	//Making an array with the users input
	int arr[] = new int [size2];
	
	//Get input from the user for each index of the array
	for (int x = 0; x < arr.length; x++) {
		System.out.println("Enter value for index "+x+" : ");
		arr[x] = in.nextInt();
	}
	
	//Compare the numbers in the array, to find the smallest one
	 int small = arr[0];//Smallest number (Starts off with it being the smallest)
	 
	 for (int z = 0; z < arr.length; z++) {
		 if (small > arr[z]) {
			 small = arr[z];
		 }
	 }
	 
	// Display the small
	 System.out.println("Smallest number amoung them is: "+small);		 
	
	 System.out.println("");
//	______________________________________________________________
	/*program that will accept positive numbers from the user (re-enter if not positive) and will display the average of the numbers entered by the use*/
	 System.out.println("____Task 3____");
	 System.out.println("Task: Restrict only positive numbers and average them");
	 System.out.println("");
	 
	//Get the size of the array from the user
	System.out.println("Enter the No. of Numbers you want to enter : ");
	int size3 = in.nextInt();
	
	//Making an array with the users input
	int arr2[] = new int [size3];
	
	//To calculate the total
	int Sum = 0;
	
	//Get input from the user for each index of the array
	for(int y = 0; y < arr2.length; y++) {
		System.out.println("Enter a value "+y);
		arr2[y] = in.nextInt();
		//Check if the input is Positive
			while (arr2[y] < 0) {
				System.out.println("Number has to be Positive: ");
				arr2[y] = in.nextInt();
			}
		//Add input to the average
		Sum += arr2[y];
	}
	
	System.out.println("");
	
	//Print the array
	System.out.print("The List of Numbers inputed: ");
	System.out.println(Arrays.toString(arr2));
	
	System.out.println("");
	
	//Average the total
	System.out.println("The Average of the numbers entered is: " + Sum/size3);
	
	System.out.println("");
	
	
//	______________________________________________________________
	/*program to count the number of positive, negative and zeros number in a list of values entered by the user*/
	System.out.println("____Task 4____");
	System.out.println("Task: Count the No.of +ve, -ve and zero numbers entered by the user");
	System.out.println("");
	
	System.out.print("How many numbers should the array be : ");
	int size4 = in.nextInt();
	int positive = 0;
	int negative = 0;
	int zero = 0;
	
	int [] arr4 = new int [size4];
	
	System.out.println("");
	
	for (int i = 0; i < arr4.length; i++) {
		System.out.print("Please enter number "+(i+1)+" : ");
		arr4[i] = in.nextInt();
		if (arr4[i] > 0 ) {
			positive++;
		}
		else if (arr4[i] < 0 ) {
			negative++;
		}
		else {
			zero++;
		}
		
		System.out.println("");
		
	}
	
	System.out.println("Number of POSITIVE values entered : "+positive);
	System.out.println("Number of NEGATIVE values entered : "+negative);
	System.out.println("Number of ZERO values entered : "+zero);

	}
	
}
