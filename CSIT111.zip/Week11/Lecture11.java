package Week11;

public class Lecture11 {
	//Seach an element
	public static boolean search_element(double arr[][], double el) {
		
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				
				if (arr[i][j] == el) {
					return true;
				}//If end
				
			}//For end
		}//For end
		
		return false;
	}//search_element End
	
	//Sum the array
	public static double sum_arr(double arr[][]) {
		double sum = 0;
	
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				
				sum += arr[i][j];
				
			}//For end
		}//For end
		
		return sum;
	}//sum_arr End
	
	//Return minimum
	public static double arr_min(double arr[][]) {
		//double min = arr[0][0]; //should work too, other way
		double my_min = +999999999;
	
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				
				if (my_min > arr[i][j]) {
					my_min = arr[i][j];
				}
				
			}//For end
		}//For end
		
		return my_min;
	}//arr_min End
	
	public static void main(String[] args) {
		/*
		 * 1-D Arrays:
		 * 		Declare
		 * 		List them
		 * 		Sum
		 * 		List w/ criteria e.g. Odd/Even 
		 */
		
		/*
		 * 2-D
		 * 		How to declare
		 * 		How to initiale
		 * 		How to display them
		 * 		Call a function and search for an element
		 * 		Call a function to sum the array
		 * 			return minimum
		 * 			sum diagonal
		 * Array: 4 , 2 (3,1)
		 * 	___________
		 * |     |     |
		 * |     |     |
		 * |     |     |
		 * |_____|_____| 
		 * 		 
		 */
		
		//Assigning and declaring
		//double [][] arr = new double [3][4];// 3 rows & 4 columns
		
		//declare and store
		double [][] arr = {	{1,6,2,7}, {0,-6,7,8}, {3,8,12,17} };
		
		//display
		System.out.println(arr[1][3]);		System.out.println("");
		//System.out.println(arr[3][1]);//out of bound
		
		
		for (int i = 0; i < arr.length; i++) {
			
			for (int j = 0; j < arr[0].length; j++) {
				System.out.print(arr[i][j] + "	| ");
			}//2nd For end
			System.out.println("");

		}//1st For end
		System.out.println("");
		
		
// Call a function and find an element
		System.out.println(search_element(arr, 18.5));
		System.out.println(search_element(arr, 1));
		System.out.println(search_element(arr, 17));
		System.out.println("");
		
		
//Call a function and sum it
		System.out.println("Sum of array: "+sum_arr(arr));
		System.out.println("");
		
//Call a function to find minimum
		System.out.println(arr_min(arr));
		
		
		
		

	}//Main

}//Class
