package Week11;

import java.util.Scanner;

public class Tut10 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter the number of rows & columns: ");
		int rows = in.nextInt();
		int cols = in.nextInt();
		
		int [][] a = new int [rows][cols];
		
		Two_D_Array obj = new Two_D_Array(rows,cols);
		
		a = obj.fill_arr();
		System.out.println("");
		
		System.out.println("Array: ");
		obj.display_arr();
		System.out.println("");System.out.println("");
		
		System.out.println("Sum of the array : "+obj.sum_fullArray());
		System.out.println("");
		
		//Sums
		obj.sum_columns();
		System.out.println("");
		
		obj.sum_rows();
		System.out.println("");
		
		System.out.println("Sum of diagnols : "+obj.sum_diagnols());
		System.out.println("");
		
		//ODD & EVEN
		obj.are_allEven();
		obj.count_even();
		System.out.println("Sum of all even numbers : "+obj.sum_even());
		System.out.println("");
		
		obj.are_allOdd();
		obj.count_odd();
		System.out.println("Sum of all odd numbers : "+obj.sum_odd());
		System.out.println("");
		
		obj.Sum_givenRow();
	}

}
