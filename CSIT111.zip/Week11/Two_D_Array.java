package Week11;

import java.util.Scanner;

public class Two_D_Array {
	Scanner in = new Scanner(System.in);
	
	private int [][] array = new int[2][2];
	
	//Defult construsctor 	
	Two_D_Array(int r,int c) {
	
		this.array = new int[r][c];
	}
	//Constructor
	Two_D_Array(int [][] array){
		
		this.array = array; 
	}
	
	
	public int [][] fill_arr(){
		
		for (int row = 0; row < array.length; row++) {
			//loops for all the rows
			for (int column = 0; column < array[row].length; column++) {
				//Loop for all the index's in the column
				
				//Ask user to input the number & save it
				System.out.println("Pls enter a number for row "+(row+1)+" and column "+(column+1)+" :");
				array[row][column] = in.nextInt();
			}//Cloumn For End
		}//Row For End
		
		return array;
	}//Fill Array End
	
	public void display_arr() {
		
		for (int row = 0; row < array.length; row++) {
			//loops for all the rows
			for (int column = 0; column < array[row].length; column++) {
				//Loop for all the index's in the column
				
				System.out.print(array[row][column]+"	");
				
			}//Cloumn For End
			System.out.println("");
		}//Row For End
	}//Display End
	
	//Sums all Numbers
	public int sum_fullArray() {
		int sum = 0;
		
		for (int row = 0; row < array.length; row++) {
			for (int col = 0; col < array[row].length; col++) {
				sum += array[row][col];
			}//Col loop end
		}//Row loop end
		
		return sum;
	}//Sum of array end
	
	//Sums all Columns 1 by 1
	public void sum_columns() {
		int sum = 0;
		int colu = 0;
		
		for (int row = 0; row < array.length; row++) {
			for (int col = 0; col < array[row].length; col++) {
				sum += array[row][col];
			}//Col loop end
			colu++;
			System.out.println("Sum of column "+colu+": "+sum);
			
			sum = 0;
		}//Row loop end
	}//Sum Column display end
	
	//Sums all Rows 1 by 1
	public void sum_rows() {
		int sum = 0;
		int rows = 0;
		
		for (int col = 0; col < array.length; col++) {
			for (int row = 0; row < array[col].length; row++) {
				sum += array[row][col];
			}//Col loop end
			rows++;
			System.out.println("Sum of row "+rows+": "+sum);
			
			sum = 0;
		}//Row loop end
	}//Sum Column display end

	//Sums all diagnols
	public int sum_diagnols() {
		int sum = 0;
		
		for (int row = 0; row < array.length; row++) {
			for (int col = 0; col < array[row].length; col++) {
				if (row == col) {
					sum += array[row][col];
				}//If end
			}//Column loop End
		}//Row loop End
		return sum;
	}//Sum of Diagnols End
	
	//EVENS
	//Even detector
	public boolean even(int num) {
		if (num%2 == 0) {
			return true;
		}
		return false;
	}
	
	//Are all Numbers even
	public void are_allEven() {
		boolean result = true;
		
		for (int row = 0; row < array.length; row++) {
			for (int col = 0; col < array[row].length; col++) {
				
				/*
				 * if (array[row][col] != 0){
				 * result = false;
				 * }
				 */
				
				if (even(array[row][col])) {
					
				}//If end
				else {
					result = false;
					break;
				}//Else end
			}//Column Loop end
		}//Row Loop end
		
		if (result == true) {
			System.out.println("All Numbers are Even");
		}
		else {
			System.out.println("All Numbers are not Even");
		}
		
	}//Are all Even end
	
	//Sums all Even Numbers
		public int sum_even() {
			int sum = 0;
			for (int row = 0; row < array.length; row++) {
				for (int col = 0; col < array[row].length; col++) {
					if ((array[row][col] % 2) == 0) {
						sum += array[row][col];
					}
					
				}//Column loop end
			}//Row Loop end
			return sum;
		}//Sum Even end
	
	//Counts all Even Numbers
	public void count_even() {
		int count = 0;
		for (int row = 0; row < array.length; row++) {
			for (int col = 0; col < array[row].length; col++) {
				if ((array[row][col] % 2) == 0) {
					count++;
				}
				
			}//Column loop end
		}//Row Loop end
		System.out.println(count+" even numbers are there");
	}//Count Even end
	
	
	//ODDS
	//Are all Numbers odd
		public void are_allOdd() {
			boolean result = true;
			
			for (int row = 0; row < array.length; row++) {
				for (int col = 0; col < array[row].length; col++) {
					  if (array[row][col] == 0){
					  result = false;
					  }

				}//Column Loop end
			}//Row Loop end
			
			if (result == true) {
				System.out.println("All Numbers are Odd");
			}
			else {
				System.out.println("All Numbers are not Odd");
			}
			
		}//Are all Odd end
		
	//Sum all Odd Numbers
	public int sum_odd() {
		int sum = 0;
		for (int row = 0; row < array.length; row++) {
			for (int col = 0; col < array[row].length; col++) {
				if ((array[row][col] % 2) != 0) {
					sum += array[row][col];
				}
				
			}//Column loop end
		}//Row Loop end
		return sum;
	}//Sum Even end
	
	//Counts all Even Numbers
	public void count_odd() {
		int count = 0;
		for (int row = 0; row < array.length; row++) {
			for (int col = 0; col < array[row].length; col++) {
				if ((array[row][col] % 2) != 0) {
					count++;
				}
				
			}//Column loop end
		}//Row Loop end
		System.out.println(count+" odd numbers are there");
	}//Count odd end
	
	//Doesnt work
	public int Sum_givenRow() {
		int sum = 0;
		
		System.out.println("Please enter the row for sum");
		int row = in.nextInt();
		
		for (int col = 0; col < array[row].length; col++) {
			sum += array[row][col];
		}
		
		return sum;
	}
	
}
