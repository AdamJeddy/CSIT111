package Week4;

import javax.swing.JOptionPane;

public class Lab03_Task03 {

	public static void main(String[] args) {
		String Marks_Text;
		Marks_Text = JOptionPane.showInputDialog("Enter Marks to get your Grades: ");
		int Mark;
		Mark = Integer.parseInt(Marks_Text);
		
		if (Mark>100) {
			JOptionPane.showMessageDialog(null, "ERROR: Enter a number in the range 0-100");
		}
		else if (Mark<0) {
			JOptionPane.showMessageDialog(null, "ERROR: Enter a number in the range 0-100");
		}
		else if (Mark>=85) {
			JOptionPane.showMessageDialog(null, "Your Grade is HD");
		}
		else if (Mark>=75){
			JOptionPane.showMessageDialog(null, "Your Grade is D");
		}
		else if (Mark>=65) {
			JOptionPane.showMessageDialog(null, "Your Grade is C");
		}
		else if (Mark>=55) {
			JOptionPane.showMessageDialog(null, "Your Grade is P");
		}
		else {
			JOptionPane.showMessageDialog(null, "Your Grade is F");
			}
	}
}
