package Week4;

import java.util.Scanner;//Import for Reading the Data from the user
import javax.swing.JOptionPane;//Import for showing

public class lab03 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
//      __________________________________________
		// Task 1
		System.out.println("Enter a Number: ");
		int n = in.nextInt();
		
		if (n%2==0)  {
			
				if (n%3==0){
					System.out.println("Number entered ("+n+") is Divisible by both 2 and 3");
				}//If End
				else {
					System.out.println("Number Entered ("+n+") is only Divisible by 2");
				}
		}//If function end 
		
//		if (n%2==0) {
//			System.out.println("Number Entered ("+n+") is only Divisible by 2");
//		
//		}//Else End
		else if (n%3==0) {
			System.out.println("Number entered ("+n+") isnt Divisible by both 2 and 3 at once");
			System.out.println("Number Entered ("+n+") is only Divisible by 3");
		}//Else If End
		else 
			System.out.println("Number isnt Divisible by Both 2 or 3");
	
//  __________________________________________	
	//Task 2
	
		System.out.println("> Enter Value for X : ");
		int X = in.nextInt();
		System.out.println("> Enter Value for Y : ");
		int Y = in.nextInt();
		System.out.println("> Enter Value for Z : ");
		int Z = in.nextInt();
		
		if (X > Y) { // IF X is the greatest 
			if (X > Z) {
				System.out.println("X ("+X+") is the greatest number");
			}
			else {
				System.out.println("Z ("+Z+") is the greatest number");
			}
		}
		else if (Y > X) {// IF Y is the greatest
			if (Y > Z) {
				System.out.println("Y ("+Y+") is the greatest number");
			}
			else {
				System.out.println("Z ("+Z+") is the greatest number");
			}
		}
		else if (Y == X) { // IF X & Y are the greatest
			if (Y == Z){
				System.out.println("All the numbers are equal");
			}
			else if (Y > Z) {
				System.out.println("Y "+Y+" & X "+X+" are both the largerst numbers");
			}
			else {
				System.out.println("Z ("+Z+") is the greatest number");
			}
		}
			
		else if (Y == Z) { // IF Y & Z are the greatest
			if (Y > X) {
				System.out.println("Y "+Y+" & Z "+Z+" are both the largerst numbers");
			}
			else {
				System.out.println("X "+X+" is the greatest number");
			}
		}
		
		else {//(X == Z) { // IF X & Z are the greatest
			if (X > Y) {
				System.out.println("X "+X+" & Z "+Z+" are both the largerst numbers");
			}
			else {
				System.out.println("Y ("+Y+") is the greatest number");
			}
		}

		//  __________________________________________	
		//Task 3
		int i = 0;
		for (int num1=10;num1>i;i++) {
		String Marks_Text;
		Marks_Text = JOptionPane.showInputDialog("Enter Marks to get your Grades: ");
		int Mark;
		Mark = Integer.parseInt(Marks_Text);
		
		if (Mark>100) {
			JOptionPane.showMessageDialog(null, "ERROR: Enter a number in the range 0-100");
		}
		else if (Mark<0) {
			JOptionPane.showMessageDialog(null, "ERROR: Enter a number in the range 0-100");
		}
		else if (Mark>=85) {
			JOptionPane.showMessageDialog(null, "Your Grade is HD");
		}
		else if (Mark>=75){
			JOptionPane.showMessageDialog(null, "Your Grade is D");
		}
		else if (Mark>=65) {
			JOptionPane.showMessageDialog(null, "Your Grade is C");
		}
		else if (Mark>=55) {
			JOptionPane.showMessageDialog(null, "Your Grade is P");
		}
		else {
			JOptionPane.showMessageDialog(null, "Your Grade is F");
			}
		}
		
	}
}