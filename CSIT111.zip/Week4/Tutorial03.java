package Week4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Tutorial03 {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		Scanner scan = new Scanner(System.in);
		
		
		int ii = 5;
		if (ii==5) {
			System.out.println("It is 5");
			System.out.println("Thank you");
		}//If End
		else {
			System.out.println("Number isnt 5");
			System.out.println("Thank you");
		}//Else End
		
		//Question 1
		int counter = 0;
		while (counter < 11) {
			System.out.println("Counter: "+counter+"||  Square Counter: "+ Math.pow(counter, 2));
			counter++;
		}//While End
		
		//Quetion 2
		 for (counter = 0; counter < 11;) {
			 System.out.println("Counter: "+counter+"||  Square Counter: "+ Math.pow(counter, 2));
			 counter++;
		 }
		 
		 //Question 3
		 System.out.println("Enter a number to find the factorial: ");
		 int factorial = scan.nextInt();
		 int product = 1;
		 
		 for (int iii= factorial; iii>=1;iii--) {
			 
			 if (factorial != 0) 
				product*=iii;	
			 else if (factorial==0)
				 product = 1;
			 else
				 System.out.println("Sorry invalid");
			 
		 }// For End 
		 System.out.println("The factorial of "+factorial+" is "+product );
		 
		 
		 //Question 5a
		System.out.println("Enter a Number: ");
		int k = scan.nextInt();
		int sum1 = 0;
			
		for (int i=1; i<=k;i++) {
			sum1 = sum1 + i;
			System.out.println(sum1);
		}// For end
		System.out.println("Sum1 is : " + sum1);
		
		 //Question 5b
		long sum2 = 0;
		
		for (int i2=1; i2<=k;i2++) {
			sum2 += Math.pow(i2, k);
		}// For end
			System.out.println("Sum 2 is : " + sum2);
			
		 //Question 6
		 BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		 String text = in.readLine();
		 System.out.println("text is: " + text);
		 
		 
		 //Question 7 
		 int a = 5; int b =6,c,d,e;
		 b=a++;
		 System.out.println("a = " +b);
		 c = ++a +5;
		 System.out.println("a = " + c);
		 d = (++a);
		 System.out.println("a = " + d);
		 e = (a++) + 8;
		 System.out.println("a = " + e);
		 b = a--;
		 System.out.println("a = " + b);
		 c = --a + a;
		 System.out.println("a = "+c);
		 d = (--a);
		 System.out.println("a = "+d);
	}
}
