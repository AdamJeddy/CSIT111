package Week4;

import java.util.Scanner;

public class Lecture_4 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a Number: ");
		int k = scan.nextInt();
		
		///////////////////////////////////////////////////////////
		//Question 1 A
		
		int sum1 = 0;
		
		for (int i=1; i<=k;i++) {
			sum1 = sum1 + i;
		}// For end
		System.out.println("Sum1 is : " + sum1);
		///////////////////////////////////////////////////////////
	
		//Question 1 B
		double sum2 = 0;
				
		for (int i=1; i<=k;i++) {
			sum2 += Math.pow(i, i);
		}//For end
		System.out.println("Sum2 is : " +sum2);
		///////////////////////////////////////////////////////////
		
		//Question 1 C
		double sum3 = 0;
		
		for (int i=1; i<=k;i++) {
			sum3 += Math.pow(i, k);
		}// For end
			System.out.println("Sum 3 is : " + sum3);
		///////////////////////////////////////////////////////////
			
		//Question 1 D & E
			//sum of the first 400 even numbers
			
		int sumEven = 0;
		int numEven= 1;
		
		int i=1;
		
		while (numEven<=400) {
			if (i % 2 == 0) {
				sumEven = sumEven + i;
				numEven ++;
				System.out.println(i+"   "+numEven);

			}//if end
				i++;//always incremented
		}//while end
		
			//sum of the first 400 odd number
		int sumOdd = 0;
		int numOdd = 1;
		i = 1;
		
		while (numOdd<=400) {
			if	(i % 2 == 1) {
				sumOdd = sumOdd + i;
				numOdd++;
				System.out.println(i+"   "+numOdd);
			}//If end
			i++;//always incremented
		}// While end
			System.out.println("Sum of the first 400 even numbers is: "+sumEven);
			System.out.println("Sum of the first 400 odd numbers is: "+sumOdd);
			///////////////////////////////////////////////////////////
			
		//Question 1 F
			
		System.out.println("Enter the value of K: ");
		int numF = scan.nextInt();
		int factorial = 1;
		int i2 = 0;
		
		if (numF == 0) System.out.println("Factorial: "+factorial); 
		if (numF > 0) {
			
			for(int i1 = 1; i1<numF ; i1++) {
				factorial = factorial *i1;
			}// end of for
			System.out.println("Factorial: "+factorial);
		}//end of if
		
		if (numF < 0) {
			System.out.println("Enter a Positive Number");
		}
	
	}//main method
}//main class
