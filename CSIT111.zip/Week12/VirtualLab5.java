package Week12;

import java.util.Scanner;

public class VirtualLab5 {
	
	public static boolean checkValue(int[][] FourxFour, int value) {
		
		for (int i = 0; i < FourxFour.length; i++) {
			for (int column = 0; column < FourxFour[i].length; column++) {
				
				//if value found then return "True"
				if (FourxFour[i][column] == value) {
					return true;
				}
				
			}//Column loop end
		}//Row loop end
		
		//Else return false
		return false;
	}//Check value End
	
	public static String returnSearchVaule(int[][] FourxFour, int value) {
		
		String answer = "";
		
		for (int row = 0; row < FourxFour.length; row++) {
			for (int column = 0; column < FourxFour[row].length; column++) {
				
				//if value found then return "True"
				if (FourxFour[row][column] == value) {
					answer = "The numeber "+value+" is on the index [row: "+(row+1)+"] [column: "+(column+1)+"]";
					return answer;
				}
				
			}//Column loop end
		}//Row loop end
		
		answer = "Value is not there in the array";
		return answer;
		
	}//Return Search value End
	
	public static int[][] swapValues(int[][] FourxFour, int value){
		int temp = 0;
		int num = 0;
		
		for (int row = 0; row < FourxFour.length; row++) {
			
			if (FourxFour[row][3] == value) {
				temp = FourxFour[row][3];
				FourxFour[row][3] = FourxFour[row][0];
				FourxFour[row][0] = temp;
				break;
			}
			
			for (int column = 0; column < FourxFour[row].length; column++) {

				if (FourxFour[row][column] == value) {
					temp = FourxFour[row][3];
					FourxFour[row][3] = FourxFour[row][column];
					FourxFour[row][column] = temp;
				}//if end
				
			}//column end
		}//row end
		
		return FourxFour;
	}//Return Swap Values

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		/* Task 1: Create a program that asks the user for numbers from 1 to 16, and store them in a 
		 * 2D array with the size of 4x4. */
		System.out.println("Task 1:");
		int [][] FourXFour = new int[4][4];
		int value = 0;
		
		for (int row = 0; row < FourXFour.length; row++) {
			for (int column = 0; column < FourXFour[row].length; column++) {
				System.out.print("Enter a value for row "+(row+1)+" and coloum "+(column+1)+" : ");
				value = in.nextInt();
				FourXFour[row][column] = value;
				//Valide the number entered
				if (value > 16 || value < 1) {
					while (true) {
						System.out.println("Number out of range, 1-16");
						System.out.print("Enter again: ");
						value = in.nextInt();
						
						if (value > 0 && value < 17) {
							FourXFour[row][column] = value;
							break;
						}//Validation if End
					}//While End
				}//If End
				
			}//Column loop end
		}//Row loop end
		
		//You didnt ask for it but i just did it
		System.out.println("Array: ");
		for (int t = 0; t < FourXFour.length; t++) {
			for (int u = 0; u < FourXFour[t].length; u++) {
				System.out.print(FourXFour[t][u]+"	");
			}//column end
			System.out.println("");
		}//Row end
		System.out.println("");
		
		
		
		/* Task 2:	Create a method that asks for search value entered by the user, and searches for said 
		 * 			input in the array created in Task 1 and return if the value is found or not. */
		System.out.println("Task 2:");
		int search1 = 0;
		System.out.println("Search 1");
		System.out.print("Enter a number to check if it exists in the array: ");
		search1 = in.nextInt();
		if (checkValue(FourXFour, search1)) {
			System.out.println("Value exists");
		}//If End
		else {
			System.out.println("Value doesnt exists");
		}//Else End
		System.out.println("");

		int search2 = 0;
		System.out.println("Search 2");
		System.out.print("Enter a number to check if it exists in the array: ");
		search2 = in.nextInt();
		if (checkValue(FourXFour, search2)) {
			System.out.println("Value exists");
		}//If End
		else {
			System.out.println("Value doesnt exists");
		}//Else End
		System.out.println("");

		
		
		/*	Task 3: Create a method that returns the index and value found in Task 2. */
		System.out.println("Task 3:");
		System.out.println(returnSearchVaule(FourXFour, search1));
		System.out.println("");

		
		
		/*	Task 4: Search the value in the array in Task 1, and swap said value with the value 
		  			found in the last location the row. If the value is found in the last location of the row, 
		  			swap said value with the value found at the first location of the row. 		 */
		
		System.out.println("Task 4:");
		System.out.println("Swap 1");
		System.out.print("Enter a value for the swap: ");
		int input = in.nextInt();
		
		int [][] newArray = swapValues(FourXFour, input);
		
		//Print the new array
		for (int t = 0; t < newArray.length; t++) {
			for (int u = 0; u < newArray[t].length; u++) {
				System.out.print(newArray[t][u]+"	");
			}//column end
			System.out.println("");
		}//Row end
		
		System.out.println("Swap 2");
		System.out.print("Enter a value for the swap: ");
		int input2 = in.nextInt();
		
		int [][] newArray2 = swapValues(FourXFour, input2);
		
		//Print the new array
		for (int t = 0; t < newArray2.length; t++) {
			for (int u = 0; u < newArray2[t].length; u++) {
				System.out.print(newArray2[t][u]+"	");
			}//column end
			System.out.println("");
		}//Row end
	}//Method End

}//Class End
