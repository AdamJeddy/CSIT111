package Week12;

import java.io.*;
import java.util.Scanner;

public class tutorial11 {

	public static void main(String[] args) throws Exception {
		File file = new File ("student11.txt");
		Scanner inf = new Scanner(file);
		
		double test [] = {0, 0, 0};
		student11 [] list = new student11[1000];
		
		int nStudent = 0;
		while (inf.hasNext()) {
			nStudent++;
			int id = inf.nextInt();
			String name = inf.next();
			test[0] = inf.nextDouble();
			test[1]	= inf.nextDouble();
			
			int n_of_tests = 3;
			double average = (test[0] + test[1])/2;
			
			student11 obj = new student11 (id, name, n_of_tests, test, average);
			list[nStudent-1] = obj;
		}//While end
		
		
		file = new File("test.txt");
		inf = new Scanner (file);
		
		while (inf.hasNext()) {
			int id = inf.nextInt();
			double mark = inf.nextDouble();
			System.out.println(mark);
			
			for (int i = 0; i < nStudent; i++) {
				if (list[i].getID() == id) {
					list[i].setMark(2, mark);
					list[i].setAverage(list[i].calculate_average());
				}//If end
			}//For end
			
		}//While end
		
		
		
	}//Method end

}//Clas end
