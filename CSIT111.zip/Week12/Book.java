package Week12;

public class Book {
	
	private String name;
	private int ISBN;
	private Author author;
	private int pub_year;
	private int n_copies;
	private String publisher;
	
	public Book(){ //defult constructor
		this.name = "";
		this.ISBN = 0000;
		this.pub_year = 0;
		this.n_copies = 0;
		this.publisher = "";
	}
	
	public Book (String name, int ISBN, Author author, int pub_year, int n_copies, String publisher) {
		this.name = name;
		this.ISBN = ISBN;
		this.author = author;
		this.pub_year = pub_year;
		this.n_copies = n_copies;
		this.publisher = publisher;
	}
	
	public String toString() {
		String str = "Name: "+name+ "	| ISBN: "+ISBN+"	| "+author.toString() + "		|PubYear: "+pub_year+ "		| Copies: "+n_copies+ "		| Publisher: "+publisher;
		return str;
	}
	
	
	public void set_nCopies(int copies) {
		this.n_copies = copies;
	}
	
	public int getisbn() {
		return ISBN;
	}
	
}
