package Week12;

public class Author {
	private String name;
	private String nationality;
	
	
	public Author () {
		
	}
	
	public Author (String name, String nationality) {
		this.name = name;
		this.nationality = nationality;
	}
	
	public String toString()	{
		String str = "AuthorName:" + name + "	| AuthorNationalaity: "+ nationality;
		return str;
	}
	

}
