package Week12;

public class student11 {
	private int id;
	private String name;
	private double [] test;//not dynamic
	private int n_of_tests;
	private double average;
	
	student11(){}
	
	student11(int id, String name, int n_of_test, double test[], double average){
		this.id = id;
		this.name = name;
		this.test = new double [n_of_test];
		for (int i = 0; i < n_of_test; i++) {
			this.test[i] = test[i];
		}
		this.n_of_tests = n_of_test;
		this.average = average;
	}//custom const
	
	//Getters
	//Setters
	//________________________
	public int getID() {
		return id;
	}
	public void setID(int id) {
		this.id = id;
	}
	
	//________________________
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	//________________________
	public int getN_of_test() {
		return n_of_tests;
	}
	public void setN_of_test(int Ntest) {
		this.n_of_tests = Ntest;
	}
	
	//________________________
	public double getAverage() {
		return average;
	}
	public void setAverage(double average) {
		this.average = average;
	}
	public double calculate_average() {
		double sum =0;
	    for (int i = 0; i < n_of_tests; i++ ) {
	         sum = sum +test[i];
	    }
	    
	    return Math.round (sum/n_of_tests * 100.0)/100.0;
	}
	
	//________________________
	public String getMarks(){
		return test[0] + " " + test[1]+ " " + test[2];
	 }
	public void setMark(int i, double mark){
		test[i] = mark;
	}
	public double SumtMark(){
		double sum =0;
	    for (int i = 0; i< test.length; i++) 
	    sum = sum +test[i];
	     
	    return sum;
	  }
	
	
	//________________________
	public String tostring(){
	    String str =  id + " " + name  + "  " + getMarks() + " " +average;
	    
	    return str;
	  }
	
}
