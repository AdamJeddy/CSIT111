package Week12;

import java.io.*;
import java.util.Scanner;

public class Lecture12 {
	
	public static void list_the_book(Book [] books, int n_books) {
		for (int k = 0; k < n_books; k++) {
			System.out.println(books[k].toString());
		}//For End
	}//list_the_book End
	
	public static Book get_book_from_list(Book [] list,int isbn, int nbook){
		for (int k = 0; k < nbook; k++) 
			if (list[k].getisbn() == isbn) return list[k];
		
		Book b = new Book();
		return b;
	}
	
	
	public static void change_ncopies(Book [] list,int nbook, int isbn,int ncopies) {
		
		Book b = get_book_from_list(list, nbook, isbn);
		
		b.set_nCopies(ncopies);	
	}//change copies End

	public static void main(String[] args) throws Exception {
		System.out.println("Welcome to our Library");
		
		File file = new File("book_list.txt");
		Scanner inf = new Scanner(file);
		Book[] list = new Book[1000];
		int nbook = 0;
		
		
		while (inf.hasNext()) {
		nbook++;
			String name = inf.next();
			int isbn = inf.nextInt();
			String aut_name = inf.next();
			String nation = inf.next();
			int pub_year = inf.nextInt();
			int n_copies = inf.nextInt();
			String publ = inf.next();
			
			Author th = new Author(aut_name, nation);
			list [nbook-1] = new Book(name, isbn, th, pub_year, n_copies, publ);
		}//While end
		
		inf.close();
		
		list_the_book(list, nbook);
		
		file = new File("isbncopy.txt");
		inf = new Scanner(file);
		
		while (inf.hasNext()) {
			int isbn = inf.nextInt();
			int ncopies = inf.nextInt();
			
			change_ncopies(list, nbook, isbn, ncopies);
			
		}
		
		
		
		
		
	}//Main end

}//Class end
